<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<div class="wrap woocommerce-page-wrap">
    <?php if ( function_exists('woocommerce_breadcrumb') ) : ?>
        <?php woocommerce_breadcrumb(); ?>
    <?php endif; ?>

    <div class="frame-x archive-frame">
        <?php woocommerce_content(); ?>
    </div>
</div>

<?php get_footer();
