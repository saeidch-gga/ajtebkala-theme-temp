<?php
/**
 * Footer template.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$ds = dentalshop_get_settings();
?>
	<footer class="site-footer">
		<div class="footer-top">
			<div class="footer-desc" id="footerDesc">
				<h3><?php echo esc_html( $ds['footer_title'] ); ?></h3>
				<?php if ( $ds['footer_text'] ) : ?>
					<p><?php echo wp_kses_post( $ds['footer_text'] ); ?></p>
					<span class="more-btn" onclick="toggleMoreText(this, 'footerDesc')"><?php esc_html_e( 'نمایش بیشتر', 'dentalshop' ); ?></span>
				<?php endif; ?>
			</div>
			<div class="trust-row">
				<?php foreach ( $ds['trust_badges'] as $badge ) :
					if ( empty( $badge['image_id'] ) ) continue;
					$img = wp_get_attachment_image( $badge['image_id'], 'thumbnail' );
					if ( ! $img ) continue;
					?>
					<?php if ( $badge['link'] ) : ?><a href="<?php echo esc_url( $badge['link'] ); ?>" class="trust-badge" target="_blank" rel="noopener"><?php else : ?><span class="trust-badge"><?php endif; ?>
						<?php echo $img; ?>
					<?php echo $badge['link'] ? '</a>' : '</span>'; ?>
				<?php endforeach; ?>
			</div>
		</div>

		<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || has_nav_menu( 'footer' ) ) : ?>
		<div class="footer-nav-row">
			<?php for ( $i = 1; $i <= 3; $i++ ) : if ( is_active_sidebar( 'footer-' . $i ) ) : dynamic_sidebar( 'footer-' . $i ); endif; endfor; ?>
		</div>
		<?php endif; ?>

		<div class="footer-bottom">
			<div class="footer-bottom-inner">
				<span>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?> — <?php esc_html_e( 'کلیه حقوق این سایت محفوظ می‌باشد.', 'dentalshop' ); ?></span>
				<span><?php esc_html_e( 'طراحی سایت و سئو توسط', 'dentalshop' ); ?> <a href="https://brandinoe.ir" target="_blank" rel="noopener" class="designer-credit"><?php esc_html_e( 'برندینو', 'dentalshop' ); ?></a></span>
			</div>
		</div>
	</footer>

	<!-- contact widget -->
	<?php
	$contact_items = array_filter( $ds['contact_items'], function ( $item ) { return ! empty( $item['label'] ); } );
	if ( $contact_items ) :
	?>
	<div class="contact-widget">
		<div class="contact-popup" id="contactPopup">
			<?php foreach ( $contact_items as $item ) : ?>
				<a href="<?php echo esc_url( $item['link'] ); ?>" class="contact-item" style="--c:<?php echo esc_attr( $item['color'] ?: '#0045E7' ); ?>" target="_blank" rel="noopener">
					<span class="c-icon">
						<?php if ( $item['image_id'] ) : echo wp_get_attachment_image( $item['image_id'], array( 20, 20 ) ); else : ?>
							<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
						<?php endif; ?>
					</span>
					<?php echo esc_html( $item['label'] ); ?>
				</a>
			<?php endforeach; ?>
		</div>
		<div class="contact-btn" id="contactToggle">
			<span class="c-ring"></span>
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
			<?php esc_html_e( 'راه‌های ارتباطی با ما', 'dentalshop' ); ?>
		</div>
	</div>
	<?php endif; ?>

	<!-- mobile bottom tab bar -->
	<nav class="bottom-tabs">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="<?php echo is_front_page() ? 'active' : ''; ?>">
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>
			<span><?php esc_html_e( 'صفحه اصلی', 'dentalshop' ); ?></span>
		</a>
		<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" id="mobileCartTab">
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h2l2.4 12.1a2 2 0 0 0 2 1.6h8.4a2 2 0 0 0 2-1.6L22 8H6"/><circle cx="9" cy="21" r="1"/><circle cx="18" cy="21" r="1"/></svg>
			<span class="cart-count"><?php echo WC()->cart ? esc_html( WC()->cart->get_cart_contents_count() ) : 0; ?></span>
			<span><?php esc_html_e( 'سبد خرید', 'dentalshop' ); ?></span>
		</a>
		<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>">
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>
			<span><?php esc_html_e( 'حساب من', 'dentalshop' ); ?></span>
		</a>
	</nav>

	<?php if ( ! is_front_page() && ! empty( $ds['site_popup_enabled'] ) && ! empty( $ds['site_popup_text'] ) ) : ?>
	<!-- site-wide promotional/information popup: max two impressions per browser -->
	<div class="site-popup-overlay" id="dsSitePopupOverlay" aria-hidden="true"></div>
	<div class="site-popup" id="dsSitePopup" role="dialog" aria-modal="true" aria-label="اطلاعیه سایت" data-revision="<?php echo esc_attr( (int) $ds['site_popup_revision'] ); ?>">
		<button type="button" class="site-popup-close" id="dsSitePopupClose" aria-label="بستن">×</button>
		<div class="site-popup-content"><?php echo wp_kses_post( $ds['site_popup_text'] ); ?></div>
	</div>
	<?php endif; ?>

	<!-- compact add-to-cart confirmation toast -->
	<div class="cart-toast" id="dsCartToast" role="status" aria-live="polite" aria-atomic="true">
		<span class="cart-toast-icon" aria-hidden="true">✓</span>
		<span><?php esc_html_e( 'کالا با موفقیت به سبد خرید اضافه شد.', 'dentalshop' ); ?></span>
	</div>

<?php wp_footer(); ?>
</body>
</html>
