<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<div class="wrap" style="padding: 30px 0 60px;">
	<nav class="breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'dentalshop' ); ?></a><span>/</span>
		<span class="current"><?php the_title(); ?></span>
	</nav>

	<div class="frame-x single-post-frame">
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class(); ?>>
				<h1 class="page-title" style="margin-top:0;"><?php the_title(); ?></h1>
				<?php if ( has_post_thumbnail() ) : ?>
					<div style="border-radius:16px; overflow:hidden; margin-bottom:24px;"><?php the_post_thumbnail( 'large' ); ?></div>
				<?php endif; ?>
				<div class="entry-content" style="font-size:0.95rem; line-height:2; color:var(--ink);">
					<?php the_content(); ?>
				</div>
			</article>
			<?php if ( comments_open() || get_comments_number() ) : ?>
				<div class="comments-frame">
					<?php comments_template(); ?>
				</div>
			<?php endif; ?>
		<?php endwhile; ?>
	</div>
</div>
<?php get_footer();
