<?php
/**
 * DentalShop theme functions.
 *
 * File map (all required at the bottom of this file):
 *   inc/setup.php            – theme supports, menus, widget areas, image sizes
 *   inc/enqueue.php          – styles & scripts
 *   inc/woocommerce.php      – WooCommerce integration & template tweaks
 *   inc/cpt-banners.php      – Hero slides / mini banners (homepage) as CPTs
 *   inc/nav-walker-mega.php  – Custom nav walker that renders the adaptive mega menu
 *   inc/customizer.php       – Site-wide options (colors are fixed by design, but
 *                              a few text fields — footer blurb, contact links — live here)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'DENTALSHOP_VERSION', '3.5.4' );
define( 'DENTALSHOP_DIR', get_template_directory() );
define( 'DENTALSHOP_URI', get_template_directory_uri() );

/**
 * This theme is built specifically around WooCommerce (product tiles,
 * cart drawer, checkout fields, etc.) — without it active, most of the
 * files below would fatal-error calling wc_*() functions. Bail out with
 * a clear admin notice instead.
 */
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) ), true ) ) {
	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-error"><p>' .
			esc_html__( 'قالب DentalShop برای کار کردن به افزونه‌ی ووکامرس نیاز دارد. لطفاً آن را نصب و فعال کنید.', 'dentalshop' ) .
			'</p></div>';
	} );
	return;
}

require DENTALSHOP_DIR . '/inc/setup.php';
require DENTALSHOP_DIR . '/inc/enqueue.php';
require DENTALSHOP_DIR . '/inc/woocommerce.php';
require DENTALSHOP_DIR . '/inc/cpt-banners.php';
require DENTALSHOP_DIR . '/inc/nav-walker-mega.php';
require DENTALSHOP_DIR . '/inc/customizer.php';
require DENTALSHOP_DIR . '/inc/ajax-search.php';
require DENTALSHOP_DIR . '/inc/single-product-helpers.php';
require DENTALSHOP_DIR . '/inc/category-editor.php';
require DENTALSHOP_DIR . '/inc/seo.php';
require DENTALSHOP_DIR . '/inc/order-tools.php';


// Mobile bottom dock sticky add to cart
add_action('woocommerce_after_single_product','ajtebkala_mobile_bottom_dock');
function ajtebkala_mobile_bottom_dock(){
    if(!wp_is_mobile()) return;
    global $product;
    if(!$product) return;
    ?>
    <div id="at-mobile-dock" class="at-mobile-dock" aria-hidden="true">
      <div class="at-mobile-dock__thumb">
        <?php echo $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ); ?>
      </div>
      <div class="at-mobile-dock__meta">
        <span class="at-mobile-dock__name"><?php echo esc_html( $product->get_name() ); ?></span>
        <span class="at-mobile-dock__price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
      </div>
      <button type="button" class="at-mobile-dock__btn"><?php esc_html_e('افزودن به سبد خرید','ajtebkala'); ?></button>
    </div>
    <?php
}


