<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<div class="wrap" style="padding: 30px 0 60px;">
	<nav class="breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'dentalshop' ); ?></a><span>/</span>
		<span class="current"><?php esc_html_e( 'اخبار و مقالات', 'dentalshop' ); ?></span>
	</nav>

	<div class="frame-x archive-frame">
		<h1 class="page-title"><?php esc_html_e( 'اخبار و مقالات', 'dentalshop' ); ?></h1>

		<div class="archive-grid archive-grid-4col">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<a href="<?php the_permalink(); ?>" class="a-card">
					<div class="a-img"><?php the_post_thumbnail( 'medium' ); ?></div>
					<div class="a-body"><?php the_title(); ?></div>
				</a>
			<?php endwhile; else : ?>
				<p><?php esc_html_e( 'هنوز مقاله‌ای منتشر نشده است.', 'dentalshop' ); ?></p>
			<?php endif; ?>
		</div>

		<?php
		$links = paginate_links( array(
			'prev_text' => '›',
			'next_text' => '‹',
			'type'      => 'array',
		) );
		if ( $links ) : ?>
			<nav class="pagination">
				<?php foreach ( $links as $link ) :
					$class = 'page-num';
					if ( false !== strpos( $link, 'prev' ) || false !== strpos( $link, 'next' ) ) $class = 'page-arrow';
					if ( false !== strpos( $link, 'dots' ) ) $class = 'page-dots';
					echo wp_kses_post( str_replace( 'page-numbers', $class, $link ) );
				endforeach; ?>
			</nav>
		<?php endif; ?>
	</div>
</div>
<?php get_footer();
