<?php
/**
 * Fallback template — used only when no more specific template
 * (front-page.php, single.php, page.php, archive.php, woocommerce.php...)
 * matches. Every WordPress theme needs at least one of these to be a
 * valid, activatable theme.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<main class="wrap" style="padding: 40px 0 60px;">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<article <?php post_class(); ?>>
			<h1><?php the_title(); ?></h1>
			<?php the_content(); ?>
		</article>
	<?php endwhile; else : ?>
		<p><?php esc_html_e( 'موردی یافت نشد.', 'dentalshop' ); ?></p>
	<?php endif; ?>
</main>
<?php get_footer();
