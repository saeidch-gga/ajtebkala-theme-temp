<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
$is_product_search = 'product' === get_query_var( 'post_type' );
?>
<div class="wrap" style="padding: 30px 0 60px;">
	<nav class="breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'dentalshop' ); ?></a><span>/</span>
		<span class="current"><?php printf( esc_html__( 'نتایج جستجو برای: %s', 'dentalshop' ), esc_html( get_search_query() ) ); ?></span>
	</nav>

	<div class="frame-x archive-frame">
		<h1 class="page-title" style="margin-top:0;"><?php printf( esc_html__( 'نتایج جستجو برای: %s', 'dentalshop' ), esc_html( get_search_query() ) ); ?></h1>

		<?php if ( have_posts() ) : ?>
			<div class="archive-grid <?php echo $is_product_search ? '' : 'archive-grid-4col'; ?>">
				<?php while ( have_posts() ) : the_post();
					if ( $is_product_search ) :
						global $product;
						if ( ! $product ) $product = wc_get_product( get_the_ID() );
						get_template_part( 'template-parts/product-tile', null, array( 'product' => $product ) );
					else : ?>
						<a href="<?php the_permalink(); ?>" class="a-card">
							<?php if ( has_post_thumbnail() ) : ?><div class="a-img"><?php the_post_thumbnail( 'medium' ); ?></div><?php endif; ?>
							<div class="a-body"><?php the_title(); ?></div>
						</a>
					<?php endif;
				endwhile; ?>
			</div>
			<?php
			$links = paginate_links( array( 'prev_text' => '›', 'next_text' => '‹', 'type' => 'array' ) );
			if ( $links ) : ?>
				<nav class="pagination">
					<?php foreach ( $links as $link ) :
						$class = 'page-num';
						if ( false !== strpos( $link, 'prev' ) || false !== strpos( $link, 'next' ) ) $class = 'page-arrow';
						if ( false !== strpos( $link, 'dots' ) ) $class = 'page-dots';
						echo wp_kses_post( str_replace( 'page-numbers', $class, $link ) );
					endforeach; ?>
				</nav>
			<?php endif; ?>
		<?php else : ?>
			<p><?php esc_html_e( 'نتیجه‌ای یافت نشد.', 'dentalshop' ); ?></p>
		<?php endif; ?>
	</div>
</div>
<?php get_footer();
