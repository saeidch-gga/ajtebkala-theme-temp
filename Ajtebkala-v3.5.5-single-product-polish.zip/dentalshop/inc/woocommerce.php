<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Shop / archive grid: 5 columns × 4 rows = 20 products per page.
 */
add_filter( 'loop_shop_columns', function () { return 5; } );
add_filter( 'loop_shop_per_page', function () { return 20; }, 20 );

/**
 * Blog archive: 4 rows × 4 columns = 16 posts per page.
 */
add_action( 'pre_get_posts', function ( $query ) {
	if ( ! is_admin() && $query->is_main_query() && is_home() ) {
		$query->set( 'posts_per_page', 16 );
	}
} );

/**
 * Strip WooCommerce's default wrapper markup — header.php / footer.php
 * already provide the site chrome, and woocommerce.php supplies our own
 * `.wrap` container so archive/single-product pages line up with the
 * rest of the site (same 70% container width).
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

/**
 * Category archive header (breadcrumb is handled separately in the
 * template so it can sit exactly where our design puts it) — remove the
 * default page title output, our archive template prints its own.
 */
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
function dentalshop_shop_toolbar() {
	echo '<div class="archive-toolbar">';
	woocommerce_result_count();
	woocommerce_catalog_ordering();
	echo '</div>';
}
add_action( 'woocommerce_before_shop_loop', 'dentalshop_shop_toolbar', 20 );

/**
 * Category description: only render the block (and its `more`-toggle
 * script) when the term actually has one — per the "no gap when there's
 * no description" requirement.
 */
remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10 );
remove_action( 'woocommerce_archive_description', 'woocommerce_product_archive_description', 10 );
function dentalshop_archive_description() {
	if ( ! is_product_taxonomy() ) return;
	$term = get_queried_object();
	if ( empty( $term->description ) ) return;
	?>
	<div class="archive-desc" id="archiveDesc">
		<div class="archive-desc-content"><?php echo wp_kses_post( $term->description ); ?></div>
		<span class="more-btn" onclick="toggleMoreText(this, 'archiveDesc')">
			<?php esc_html_e( 'نمایش بیشتر', 'dentalshop' ); ?>
		</span>
	</div>
	<?php
}
add_action( 'woocommerce_archive_description', 'dentalshop_archive_description', 10 );

/**
 * Sale badge → show the percentage off ("−25%") instead of a generic
 * "Sale" flash, and a "sold out" badge when out of stock.
 */
function dentalshop_sale_badge( $html, $post, $product ) {
	if ( ! $product->is_on_sale() ) {
		return $product->is_in_stock() ? '' : '<span class="badge sold-out">' . esc_html__( 'ناموجود', 'dentalshop' ) . '</span>';
	}
	$regular = (float) $product->get_regular_price();
	$sale    = (float) $product->get_sale_price();
	if ( $regular > 0 ) {
		$pct = round( ( ( $regular - $sale ) / $regular ) * 100 );
		return '<span class="badge">' . $pct . '%</span>';
	}
	return '<span class="badge">' . esc_html__( 'حراج', 'dentalshop' ) . '</span>';
}
add_filter( 'woocommerce_sale_flash', 'dentalshop_sale_badge', 10, 3 );

/**
 * Cart count badge (header + mobile bottom tab) via WooCommerce's AJAX
 * cart fragments, so it updates instantly on add-to-cart without a
 * full page reload.
 */
function dentalshop_cart_fragments( $fragments ) {
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	ob_start();
	?><span class="cart-count"><?php echo esc_html( $count ); ?></span><?php
	$fragments['span.cart-count'] = ob_get_clean();
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'dentalshop_cart_fragments' );

/**
 * Related products: reuse the same "5 tiles + arrows" slider markup as
 * everywhere else instead of WooCommerce's default related-products grid.
 * The actual query stays WooCommerce's default (same category, in stock).
 */
add_filter( 'woocommerce_output_related_products_args', function ( $args ) {
	$args['posts_per_page'] = 10; // fetch a few extra so the slider has room to scroll
	$args['columns']        = 5;
	return $args;
} );

/**
 * Digits (mobile-number + OTP login/registration) compatibility notes:
 * ----------------------------------------------------------------------
 * Digits replaces WooCommerce's default email/password My Account forms
 * via its own hooks into `woocommerce_login_form` / registration templates
 * — this theme does NOT override those templates directly (see
 * woocommerce/myaccount/form-login.php is intentionally absent), so
 * Digits' own markup renders untouched and simply inherits this theme's
 * global typography/colors. The "verified" phone badge and disabled
 * phone field in template-parts/account/details.php are cosmetic only;
 * Digits still owns the actual phone verification logic.
 *
 * Advanced Shipping for WooCommerce (Jeroen Sormani) compatibility:
 * ----------------------------------------------------------------------
 * The plugin renders its own shipping method rows via WooCommerce's
 * standard `woocommerce_cart_shipping_method_full_label` /
 * `review-order.php` hooks — our cart/checkout templates keep those
 * hooks in place (see woocommerce/cart/cart-shipping.php override) and
 * only add the `.shipping-option` wrapper classes for styling, so the
 * plugin's own logic and pricing rules keep working unmodified.
 */

/**
 * Restyle the default WooCommerce breadcrumb to match the theme's
 * `.breadcrumb` design used throughout the mockups.
 */
add_filter( 'woocommerce_breadcrumb_defaults', function ( $defaults ) {
	$defaults['wrap_before'] = '<nav class="breadcrumb woocommerce-breadcrumb">';
	$defaults['wrap_after']  = '</nav>';
	$defaults['before']      = '';
	$defaults['after']       = '';
	$defaults['delimiter']   = '<span>/</span>';
	return $defaults;
} );

/**
 * Disable WooCommerce's own default stylesheets (woocommerce.css,
 * woocommerce-layout.css, woocommerce-smallscreen.css) entirely. This
 * theme's assets/css/main.css supplies 100% of the visual design for
 * every WooCommerce page/component — WC's defaults were only ever
 * fighting with it (default purple buttons, 50/50 field widths that
 * didn't match our grid, stretched cart-item thumbnails, etc.).
 */
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );

/**
 * Suppress WooCommerce's default "added to cart" notice box — replaced
 * by a custom animated popup (assets/js/main.js reads the `added-to-cart`
 * URL parameter WooCommerce redirects back with, see #dsAddedPopup).
 */
add_filter( 'wc_add_to_cart_message_html', '__return_empty_string' );

remove_action( 'woocommerce_checkout_order_review', 'woocommerce_order_review', 10 );

require DENTALSHOP_DIR . '/inc/checkout-fields.php';
