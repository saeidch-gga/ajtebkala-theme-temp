<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Hero slider slides — homepage's main 70%-wide banner. Each slide is
 * just a featured image + a link; order is whatever order they're listed
 * in the admin (drag to reorder via menu_order, same as Page Attributes).
 */
function dentalshop_register_hero_slide_cpt() {
	register_post_type( 'ds_hero_slide', array(
		'labels' => array(
			'name'          => 'اسلایدهای بنر اصلی',
			'singular_name' => 'اسلاید بنر اصلی',
			'add_new_item'  => 'افزودن اسلاید جدید',
			'edit_item'     => 'ویرایش اسلاید',
			'all_items'     => 'همه‌ی اسلایدها (حداکثر ۷ عدد)',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'menu_icon'    => 'dashicons-images-alt2',
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
	) );
}
add_action( 'init', 'dentalshop_register_hero_slide_cpt' );

/**
 * Generic slotted banner — side banners, the 4-up mini-banner row, and
 * the full-width ad banner all use this one post type, distinguished by
 * the "slot" meta field. `mini_row` is the only repeatable slot (up to
 * four); the others are singular — the theme just uses the latest
 * published post for that slot.
 */
function dentalshop_register_banner_cpt() {
	register_post_type( 'ds_banner', array(
		'labels' => array(
			'name'          => 'بنرهای سایت',
			'singular_name' => 'بنر',
			'add_new_item'  => 'افزودن بنر جدید',
			'edit_item'     => 'ویرایش بنر',
			'all_items'     => 'همه‌ی بنرها',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => 'edit.php?post_type=ds_hero_slide',
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
	) );
}
add_action( 'init', 'dentalshop_register_banner_cpt' );

function dentalshop_banner_slots() {
	return array(
		'side_1'   => 'بنر کناری ۱ (کنار بنر اصلی، بالا)',
		'side_2'   => 'بنر کناری ۲ (کنار بنر اصلی، پایین)',
		'mini_row' => 'ردیف ۴ بنر (بین اسلایدر پرفروش‌ها و جدیدترین‌ها)',
		'ad_full'  => 'بنر تبلیغاتی تمام‌عرض (بعد از اسلایدر جدیدترین‌ها)',
	);
}

/**
 * Meta boxes: link URL for hero slides, and slot + link for banners.
 */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'ds_slide_link', 'لینک اسلاید', 'dentalshop_render_link_meta_box', 'ds_hero_slide', 'side' );
	add_meta_box( 'ds_banner_meta', 'تنظیمات بنر', 'dentalshop_render_banner_meta_box', 'ds_banner', 'side' );
} );

function dentalshop_render_link_meta_box( $post ) {
	wp_nonce_field( 'ds_save_meta', 'ds_meta_nonce' );
	$link = get_post_meta( $post->ID, '_ds_link', true );
	echo '<label for="ds_link">آدرس لینک (وقتی روی بنر کلیک شود):</label>';
	echo '<input type="url" style="width:100%;margin-top:6px;" id="ds_link" name="ds_link" value="' . esc_attr( $link ) . '" placeholder="https://">';
}

function dentalshop_render_banner_meta_box( $post ) {
	wp_nonce_field( 'ds_save_meta', 'ds_meta_nonce' );
	$link = get_post_meta( $post->ID, '_ds_link', true );
	$slot = get_post_meta( $post->ID, '_ds_slot', true );
	echo '<p><label for="ds_slot">جایگاه نمایش:</label><br>';
	echo '<select id="ds_slot" name="ds_slot" style="width:100%;">';
	foreach ( dentalshop_banner_slots() as $key => $label ) {
		echo '<option value="' . esc_attr( $key ) . '" ' . selected( $slot, $key, false ) . '>' . esc_html( $label ) . '</option>';
	}
	echo '</select></p>';
	echo '<p><label for="ds_link">آدرس لینک:</label><br>';
	echo '<input type="url" style="width:100%;" id="ds_link" name="ds_link" value="' . esc_attr( $link ) . '" placeholder="https://"></p>';
}

add_action( 'save_post_ds_hero_slide', 'dentalshop_save_banner_meta' );
add_action( 'save_post_ds_banner', 'dentalshop_save_banner_meta' );
function dentalshop_save_banner_meta( $post_id ) {
	if ( ! isset( $_POST['ds_meta_nonce'] ) || ! wp_verify_nonce( $_POST['ds_meta_nonce'], 'ds_save_meta' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	if ( isset( $_POST['ds_link'] ) ) {
		update_post_meta( $post_id, '_ds_link', esc_url_raw( wp_unslash( $_POST['ds_link'] ) ) );
	}
	if ( isset( $_POST['ds_slot'] ) ) {
		update_post_meta( $post_id, '_ds_slot', sanitize_key( $_POST['ds_slot'] ) );
	}
}

/**
 * Helpers used by front-page.php.
 */
function dentalshop_get_hero_slides( $limit = 7 ) {
	return get_posts( array(
		'post_type'      => 'ds_hero_slide',
		'posts_per_page' => $limit,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
	) );
}

function dentalshop_get_banner_by_slot( $slot ) {
	$posts = get_posts( array(
		'post_type'      => 'ds_banner',
		'posts_per_page' => 1,
		'meta_key'       => '_ds_slot',
		'meta_value'     => $slot,
	) );
	return $posts ? $posts[0] : null;
}

function dentalshop_get_mini_row_banners( $limit = 4 ) {
	return get_posts( array(
		'post_type'      => 'ds_banner',
		'posts_per_page' => $limit,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'meta_key'       => '_ds_slot',
		'meta_value'     => 'mini_row',
	) );
}
