<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function dentalshop_preload_fonts() {
	$regular = DENTALSHOP_URI . '/assets/fonts/Vazirmatn-RD-Regular.woff2';
	echo '<link rel="preload" href="' . esc_url( $regular ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	$bold_file = DENTALSHOP_DIR . '/assets/fonts/Vazirmatn-Bold.woff2';
	if ( file_exists( $bold_file ) ) {
		$bold = DENTALSHOP_URI . '/assets/fonts/Vazirmatn-Bold.woff2';
		echo '<link rel="preload" href="' . esc_url( $bold ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	}
}
add_action( 'wp_head', 'dentalshop_preload_fonts', 1 );

/**
 * Cache-busting version string based on the file's actual last-modified
 * time, so every real edit automatically forces browsers/CDNs to fetch
 * the fresh copy — no need to remember to bump a version number by hand.
 */
/**
 * Cache-busting version string based on the file's actual last-modified
 * time, so every real edit automatically forces browsers/CDNs to fetch
 * the fresh copy — no need to remember to bump a version number by hand.
 */
function dentalshop_asset_version( $relative_path ) {
	$file = DENTALSHOP_DIR . $relative_path;
	return file_exists( $file ) ? filemtime( $file ) : DENTALSHOP_VERSION;
}

function dentalshop_scripts() {
	// Self-hosted font loading (Google Fonts removed for performance)
	wp_enqueue_style(
		'dentalshop-font-local',
		DENTALSHOP_URI . '/assets/css/font-local.css',
		array(),
		dentalshop_asset_version( '/assets/css/font-local.css' )
	);

	
	wp_enqueue_style( 'dentalshop-base', DENTALSHOP_URI . '/assets/css/base.css', array(), dentalshop_asset_version( '/assets/css/base.css' ) );
	wp_enqueue_style( 'dentalshop-components', DENTALSHOP_URI . '/assets/css/components.css', array('dentalshop-base'), dentalshop_asset_version( '/assets/css/components.css' ) );

	if ( is_front_page() ) {
		wp_enqueue_style( 'dentalshop-home', DENTALSHOP_URI . '/assets/css/home.css', array('dentalshop-components'), dentalshop_asset_version( '/assets/css/home.css' ) );
	} elseif ( is_product() ) {
		wp_enqueue_style( 'dentalshop-product', DENTALSHOP_URI . '/assets/css/product.css', array('dentalshop-components'), dentalshop_asset_version( '/assets/css/product.css' ) );
	} elseif ( is_shop() || is_product_taxonomy() || is_search() ) {
		wp_enqueue_style( 'dentalshop-archive', DENTALSHOP_URI . '/assets/css/archive.css', array('dentalshop-components'), dentalshop_asset_version( '/assets/css/archive.css' ) );
	}

	wp_enqueue_style( 'dentalshop-style', get_stylesheet_uri(), array(), DENTALSHOP_VERSION );
	wp_enqueue_style( 'dentalshop-main', DENTALSHOP_URI . '/assets/css/main.css', array('dentalshop-components'), dentalshop_asset_version( '/assets/css/main.css' ) );

	// Keep WooCommerce's native variation controller loaded for variable products.
	if ( is_product() ) {
		global $product;
		if ( $product instanceof WC_Product && $product->is_type( 'variable' ) ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
		}
	}

	wp_enqueue_script( 'dentalshop-main', DENTALSHOP_URI . '/assets/js/main.js', array(), dentalshop_asset_version( '/assets/js/main.js' ), true );

	wp_localize_script( 'dentalshop-main', 'dentalshopData', array(
		'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
		'nonce'      => wp_create_nonce( 'dentalshop_ajax' ),
		'cartUrl'    => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
		'checkoutUrl'=> function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
	) );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'dentalshop_scripts' );

/**
 * Admin-side styles for the custom meta boxes (banners, mega menu columns).
 */
function dentalshop_admin_scripts( $hook ) {
	wp_enqueue_style( 'dentalshop-admin', DENTALSHOP_URI . '/assets/css/admin.css', array( 'dashicons' ), DENTALSHOP_VERSION );
	wp_enqueue_media(); // image picker for banners / mega menu icons
	wp_enqueue_script( 'dentalshop-admin', DENTALSHOP_URI . '/assets/js/admin.js', array( 'jquery' ), DENTALSHOP_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'dentalshop_admin_scripts' );
