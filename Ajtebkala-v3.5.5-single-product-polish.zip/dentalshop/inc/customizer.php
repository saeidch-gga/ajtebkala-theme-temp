<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * "تنظیمات فروشگاه" — one admin page covering everything that was
 * hardcoded text/links in the original HTML mockups: the footer blurb,
 * the 4 footer trust badges, the "راه‌های ارتباطی با ما" contact list,
 * and which product category/tag feeds each homepage slider.
 *
 * Kept as a single Settings-API-free page (plain POST + option) to
 * avoid pulling in extra libraries — swap for ACF Options Pages later
 * if the content team wants a richer editing UI.
 */

add_action( 'admin_menu', function () {
	add_menu_page(
		'تنظیمات فروشگاه', 'تنظیمات فروشگاه', 'manage_options',
		'dentalshop-settings', 'dentalshop_render_settings_page', 'dashicons-admin-customizer', 59
	);
} );

function dentalshop_default_settings() {
	return array(
		'footer_title' => 'خرید و فروش تجهیزات دندانپزشکی',
		'footer_text'  => '',
		'trust_badges' => array_fill( 0, 4, array( 'image_id' => 0, 'link' => '' ) ),
		'contact_items'=> array_fill( 0, 4, array( 'label' => '', 'color' => '#0045E7', 'link' => '', 'image_id' => 0 ) ),
		'slider_1_title'    => 'محصولات پرفروش',
		'slider_1_category' => 0,
		'slider_2_title'    => 'جدیدترین محصولات',
		'slider_2_category' => 0,
		'slider_3_title'    => 'پیشنهاد ویژه برای شما',
		'slider_3_category' => 0,
		'gold_product_tag'  => '',
		'gold_countdown_end'=> '',
		'homepage_categories' => array(),
		'trust_shipping_label' => 'ارسال سریع',
		'site_popup_enabled' => false,
		'site_popup_text' => '',
		'site_popup_revision' => 1,
	);
}

function dentalshop_get_settings() {
	return wp_parse_args( get_option( 'dentalshop_settings', array() ), dentalshop_default_settings() );
}

function dentalshop_render_settings_page() {
	if ( isset( $_POST['dentalshop_settings_nonce'] ) && wp_verify_nonce( $_POST['dentalshop_settings_nonce'], 'save' ) ) {
		$old = dentalshop_get_settings();
		$s = dentalshop_default_settings();

		$s['footer_title'] = sanitize_text_field( wp_unslash( $_POST['footer_title'] ?? '' ) );
		$s['footer_text']  = wp_kses_post( wp_unslash( $_POST['footer_text'] ?? '' ) );

		for ( $i = 0; $i < 4; $i++ ) {
			$s['trust_badges'][ $i ] = array(
				'image_id' => absint( $_POST["trust_image_$i"] ?? 0 ),
				'link'     => esc_url_raw( wp_unslash( $_POST["trust_link_$i"] ?? '' ) ),
			);
			$s['contact_items'][ $i ] = array(
				'label'    => sanitize_text_field( wp_unslash( $_POST["contact_label_$i"] ?? '' ) ),
				'color'    => sanitize_hex_color( wp_unslash( $_POST["contact_color_$i"] ?? '' ) ),
				'link'     => esc_url_raw( wp_unslash( $_POST["contact_link_$i"] ?? '' ) ),
				'image_id' => absint( $_POST["contact_image_$i"] ?? 0 ),
			);
		}

		foreach ( array( 1, 2, 3 ) as $n ) {
			$s["slider_{$n}_title"]    = sanitize_text_field( wp_unslash( $_POST["slider_{$n}_title"] ?? '' ) );
			$s["slider_{$n}_category"] = absint( $_POST["slider_{$n}_category"] ?? 0 );
		}

		$s['gold_product_tag']   = sanitize_text_field( wp_unslash( $_POST['gold_product_tag'] ?? '' ) );
		$s['gold_countdown_end'] = sanitize_text_field( wp_unslash( $_POST['gold_countdown_end'] ?? '' ) );
		$s['homepage_categories'] = array_map( 'absint', (array) ( $_POST['homepage_categories'] ?? array() ) );
		$s['trust_shipping_label'] = sanitize_text_field( wp_unslash( $_POST['trust_shipping_label'] ?? '' ) );
		$s['site_popup_enabled'] = ! empty( $_POST['site_popup_enabled'] );
		$s['site_popup_text'] = wp_kses_post( wp_unslash( $_POST['site_popup_text'] ?? '' ) );
		$s['site_popup_revision'] = (int) ( $old['site_popup_revision'] ?? 1 );
		if ( $s['site_popup_enabled'] !== (bool) $old['site_popup_enabled'] || $s['site_popup_text'] !== $old['site_popup_text'] ) {
			$s['site_popup_revision']++;
		}

		update_option( 'dentalshop_settings', $s );
		echo '<div class="updated"><p>تنظیمات ذخیره شد.</p></div>';
	}

	$s = dentalshop_get_settings();
	$product_categories = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	?>
	<div class="wrap ds-settings">
		<h1>تنظیمات فروشگاه</h1>
		<form method="post">
			<?php wp_nonce_field( 'save', 'dentalshop_settings_nonce' ); ?>

			<h2>فوتر — متن معرفی</h2>
			<table class="form-table">
				<tr><th>عنوان</th><td><input type="text" name="footer_title" value="<?php echo esc_attr( $s['footer_title'] ); ?>" class="regular-text"></td></tr>
				<tr><th>متن کامل</th><td><?php wp_editor( $s['footer_text'], 'footer_text', array( 'textarea_name' => 'footer_text', 'media_buttons' => false, 'textarea_rows' => 5 ) ); ?>
				<p class="description">در سایت فقط ۲ خط اول نمایش داده می‌شود؛ بقیه با دکمه‌ی «نمایش بیشتر» باز می‌شود.</p></td></tr>
			</table>

			<h2>فوتر — ۴ آیکون اعتماد</h2>
			<table class="widefat">
				<thead><tr><th>تصویر</th><th>لینک</th></tr></thead>
				<tbody>
				<?php for ( $i = 0; $i < 4; $i++ ) :
					$badge = $s['trust_badges'][ $i ]; ?>
					<tr>
						<td><?php dentalshop_media_picker_field( "trust_image_$i", $badge['image_id'] ); ?></td>
						<td><input type="url" name="trust_link_<?php echo $i; ?>" value="<?php echo esc_attr( $badge['link'] ); ?>" class="regular-text" placeholder="https://"></td>
					</tr>
				<?php endfor; ?>
				</tbody>
			</table>

			<h2>«راه‌های ارتباطی با ما» — تا ۴ مورد</h2>
			<table class="widefat">
				<thead><tr><th>آیکون</th><th>عنوان</th><th>رنگ</th><th>لینک</th></tr></thead>
				<tbody>
				<?php for ( $i = 0; $i < 4; $i++ ) :
					$c = $s['contact_items'][ $i ]; ?>
					<tr>
						<td><?php dentalshop_media_picker_field( "contact_image_$i", $c['image_id'] ); ?></td>
						<td><input type="text" name="contact_label_<?php echo $i; ?>" value="<?php echo esc_attr( $c['label'] ); ?>" placeholder="مثلاً: واتساپ"></td>
						<td><input type="color" name="contact_color_<?php echo $i; ?>" value="<?php echo esc_attr( $c['color'] ?: '#0045E7' ); ?>"></td>
						<td><input type="url" name="contact_link_<?php echo $i; ?>" value="<?php echo esc_attr( $c['link'] ); ?>" class="regular-text" placeholder="https://"></td>
					</tr>
				<?php endfor; ?>
				</tbody>
			</table>

			<h2>اسلایدرهای محصول (صفحه اصلی)</h2>
			<table class="form-table">
				<?php foreach ( array( 1, 2, 3 ) as $n ) : ?>
					<tr>
						<th>اسلایدر <?php echo $n; ?></th>
						<td>
							عنوان: <input type="text" name="slider_<?php echo $n; ?>_title" value="<?php echo esc_attr( $s["slider_{$n}_title"] ); ?>"><br><br>
							دسته‌بندی محصول:
							<select name="slider_<?php echo $n; ?>_category">
								<option value="0">— انتخاب کنید —</option>
								<?php foreach ( $product_categories as $cat ) : ?>
									<option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( $s["slider_{$n}_category"], $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>

			<h2>پیشنهادات طلایی</h2>
			<table class="form-table">
				<tr><th>برچسب محصول (تگ)</th><td><input type="text" name="gold_product_tag" value="<?php echo esc_attr( $s['gold_product_tag'] ); ?>" placeholder="مثلاً: pishnahad-talaei"></td></tr>
				<tr><th>پایان شمارش معکوس</th><td><input type="datetime-local" name="gold_countdown_end" value="<?php echo esc_attr( $s['gold_countdown_end'] ); ?>"></td></tr>
			</table>

			<h2>۴ مورد اعتماد صفحه‌ی محصول</h2>
			<table class="form-table">
				<tr><th>متن مورد اول (ارسال سریع)</th><td><input type="text" name="trust_shipping_label" value="<?php echo esc_attr( $s['trust_shipping_label'] ); ?>" class="regular-text"></td></tr>
			</table>
			<p class="description">۳ مورد دیگر (ضمانت اصالت کالا، پشتیبانی فنی، ضمانت بازگشت وجه) ثابت هستند.</p>

			<h2>پاپ‌آپ عمومی سایت</h2>
		<table class="form-table">
			<tr>
				<th>فعال‌سازی</th>
				<td>
					<label><input type="checkbox" name="site_popup_enabled" value="1" <?php checked( $s['site_popup_enabled'] ); ?>> نمایش پاپ‌آپ در تمام صفحات به‌جز صفحه اصلی</label>
					<p class="description">برای هر مرورگر جدید، پاپ‌آپ حداکثر ۲ بار نمایش داده می‌شود. با تغییر متن یا وضعیت، شمارنده کاربران از نو شروع می‌شود.</p>
				</td>
			</tr>
			<tr>
				<th>متن پاپ‌آپ</th>
				<td>
					<?php wp_editor( $s['site_popup_text'], 'site_popup_text', array( 'textarea_name' => 'site_popup_text', 'media_buttons' => false, 'textarea_rows' => 6, 'teeny' => true ) ); ?>
					<p class="description">می‌توانید از لینک، بولد و شکست خط استفاده کنید. ظاهر پاپ‌آپ از طراحی قالب پیروی می‌کند.</p>
				</td>
			</tr>
		</table>

		<h2>۶ دسته‌بندی اصلی (صفحه اول)</h2>
			<p class="description">حداکثر ۶ مورد انتخاب کنید؛ ترتیب نمایش همان ترتیب انتخاب زیر است.</p>
			<?php foreach ( $product_categories as $cat ) : ?>
				<label style="display:inline-block;width:23%;margin:4px 0;">
					<input type="checkbox" name="homepage_categories[]" value="<?php echo esc_attr( $cat->term_id ); ?>"
						<?php checked( in_array( $cat->term_id, $s['homepage_categories'], true ) ); ?>>
					<?php echo esc_html( $cat->name ); ?>
				</label>
			<?php endforeach; ?>

			<p class="submit"><button class="button button-primary">ذخیره‌ی همه‌ی تنظیمات</button></p>
		</form>
	</div>
	<?php
}

/**
 * A single "انتخاب تصویر" media-picker field: hidden input holding the
 * attachment ID + a thumbnail preview, wired up by assets/js/admin.js.
 */
function dentalshop_media_picker_field( $name, $image_id ) {
	$src = $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '';
	?>
	<div class="ds-media-picker">
		<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $image_id ); ?>" class="ds-media-id">
		<img src="<?php echo esc_url( $src ); ?>" style="width:50px;height:50px;object-fit:cover;border-radius:6px;<?php echo $src ? '' : 'display:none;'; ?>" class="ds-media-preview">
		<button type="button" class="button ds-media-select">انتخاب تصویر</button>
	</div>
	<?php
}
