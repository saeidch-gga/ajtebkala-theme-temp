<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * "فیلدهای پرداخت" admin page — lets a shop manager turn standard
 * checkout fields on/off, toggle required/optional, and add up to two
 * custom fields (e.g. "کد ملی", "نام مطب") without touching code.
 *
 * This is intentionally a lightweight settings page rather than a full
 * drag-and-drop builder — it covers exactly the "add/remove fields"
 * requirement discussed. If the shop later needs more than 2 custom
 * fields or field re-ordering, swapping this for a plugin like
 * "WooCommerce Checkout Field Editor" is a drop-in replacement — the
 * `dentalshop_checkout_fields` filter below would simply be removed.
 */

define( 'DENTALSHOP_CHECKOUT_FIELDS_OPTION', 'dentalshop_checkout_fields' );

function dentalshop_checkout_fields_defaults() {
	return array(
		'first_name'    => array( 'enabled' => 1, 'required' => 1, 'label' => 'نام' ),
		'last_name'     => array( 'enabled' => 1, 'required' => 1, 'label' => 'نام خانوادگی' ),
		'phone'         => array( 'enabled' => 1, 'required' => 1, 'label' => 'شماره موبایل' ),
		'email'         => array( 'enabled' => 1, 'required' => 0, 'label' => 'ایمیل (اختیاری)' ),
		'address_1'     => array( 'enabled' => 1, 'required' => 1, 'label' => 'آدرس کامل پستی' ),
		'city'          => array( 'enabled' => 1, 'required' => 1, 'label' => 'شهر' ),
		'state'         => array( 'enabled' => 1, 'required' => 1, 'label' => 'استان' ),
		'postcode'      => array( 'enabled' => 1, 'required' => 1, 'label' => 'کد پستی' ),
		'order_comments'=> array( 'enabled' => 1, 'required' => 0, 'label' => 'یادداشت سفارش' ),
		'custom_1'      => array( 'enabled' => 0, 'required' => 0, 'label' => '', 'type' => 'text' ),
		'custom_2'      => array( 'enabled' => 0, 'required' => 0, 'label' => '', 'type' => 'text' ),
	);
}

function dentalshop_get_checkout_field_settings() {
	$saved = get_option( DENTALSHOP_CHECKOUT_FIELDS_OPTION, array() );
	return wp_parse_args( $saved, dentalshop_checkout_fields_defaults() );
}

add_action( 'admin_menu', function () {
	add_submenu_page(
		'woocommerce',
		'فیلدهای پرداخت',
		'فیلدهای پرداخت',
		'manage_woocommerce',
		'dentalshop-checkout-fields',
		'dentalshop_render_checkout_fields_page'
	);
} );

function dentalshop_render_checkout_fields_page() {
	if ( isset( $_POST['dentalshop_checkout_fields_nonce'] ) && wp_verify_nonce( $_POST['dentalshop_checkout_fields_nonce'], 'save' ) ) {
		$defaults = dentalshop_checkout_fields_defaults();
		$new      = array();
		foreach ( $defaults as $key => $field ) {
			$new[ $key ] = array(
				'enabled'  => isset( $_POST[ "enabled_$key" ] ) ? 1 : 0,
				'required' => isset( $_POST[ "required_$key" ] ) ? 1 : 0,
				'label'    => isset( $_POST[ "label_$key" ] ) ? sanitize_text_field( wp_unslash( $_POST[ "label_$key" ] ) ) : $field['label'],
			);
			if ( isset( $field['type'] ) ) {
				$new[ $key ]['type'] = isset( $_POST[ "type_$key" ] ) ? sanitize_key( $_POST[ "type_$key" ] ) : 'text';
			}
		}
		update_option( DENTALSHOP_CHECKOUT_FIELDS_OPTION, $new );
		echo '<div class="updated"><p>تنظیمات ذخیره شد.</p></div>';
	}

	$fields = dentalshop_get_checkout_field_settings();
	?>
	<div class="wrap">
		<h1>فیلدهای فرم پرداخت</h1>
		<p>فیلدهای پیش‌فرض را فعال/غیرفعال یا اجباری/اختیاری کنید، عنوانشان را ویرایش کنید، یا تا ۲ فیلد سفارشی اضافه کنید.</p>
		<form method="post">
			<?php wp_nonce_field( 'save', 'dentalshop_checkout_fields_nonce' ); ?>
			<table class="widefat striped">
				<thead>
					<tr><th>فعال</th><th>اجباری</th><th>عنوان نمایشی</th><th>کلید فیلد</th></tr>
				</thead>
				<tbody>
					<?php foreach ( $fields as $key => $field ) :
						$is_custom = strpos( $key, 'custom_' ) === 0;
					?>
					<tr>
						<td><input type="checkbox" name="enabled_<?php echo esc_attr( $key ); ?>" <?php checked( $field['enabled'], 1 ); ?>></td>
						<td><input type="checkbox" name="required_<?php echo esc_attr( $key ); ?>" <?php checked( $field['required'], 1 ); ?>></td>
						<td>
							<input type="text" name="label_<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $field['label'] ); ?>"
								placeholder="<?php echo $is_custom ? 'مثلاً: کد ملی' : ''; ?>" style="width:100%;">
						</td>
						<td><code><?php echo esc_html( $key ); ?></code></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="submit"><button class="button button-primary">ذخیره تغییرات</button></p>
		</form>
	</div>
	<?php
}

/**
 * Apply the saved settings to WooCommerce's actual checkout fields.
 */
add_filter( 'woocommerce_checkout_fields', 'dentalshop_checkout_fields' );
function dentalshop_checkout_fields( $wc_fields ) {
	$settings = dentalshop_get_checkout_field_settings();
	$map      = array(
		'first_name' => array( 'billing', 'billing_first_name' ),
		'last_name'  => array( 'billing', 'billing_last_name' ),
		'phone'      => array( 'billing', 'billing_phone' ),
		'email'      => array( 'billing', 'billing_email' ),
		'address_1'  => array( 'billing', 'billing_address_1' ),
		'city'       => array( 'billing', 'billing_city' ),
		'state'      => array( 'billing', 'billing_state' ),
		'postcode'   => array( 'billing', 'billing_postcode' ),
	);

	foreach ( $map as $key => $loc ) {
		list( $section, $field_key ) = $loc;
		if ( empty( $settings[ $key ]['enabled'] ) ) {
			unset( $wc_fields[ $section ][ $field_key ] );
			continue;
		}
		if ( ! isset( $wc_fields[ $section ][ $field_key ] ) ) continue;
		$wc_fields[ $section ][ $field_key ]['required'] = ! empty( $settings[ $key ]['required'] );
		$wc_fields[ $section ][ $field_key ]['label']    = $settings[ $key ]['label'];
	}

	if ( empty( $settings['order_comments']['enabled'] ) ) {
		unset( $wc_fields['order']['order_comments'] );
	} elseif ( isset( $wc_fields['order']['order_comments'] ) ) {
		$wc_fields['order']['order_comments']['required'] = ! empty( $settings['order_comments']['required'] );
		$wc_fields['order']['order_comments']['label']    = $settings['order_comments']['label'];
	}

	// Custom fields 1 & 2, appended to the billing/address section.
	foreach ( array( 'custom_1', 'custom_2' ) as $ck ) {
		if ( empty( $settings[ $ck ]['enabled'] ) || empty( $settings[ $ck ]['label'] ) ) continue;
		$wc_fields['billing'][ 'billing_' . $ck ] = array(
			'type'     => 'text',
			'label'    => $settings[ $ck ]['label'],
			'required' => ! empty( $settings[ $ck ]['required'] ),
			'class'    => array( 'form-row-wide' ),
			'priority' => 120,
		);
	}

	return $wc_fields;
}

/**
 * Persist the custom fields on the order (so they show up in admin +
 * order emails), same pattern WooCommerce uses for its own meta.
 */
add_action( 'woocommerce_checkout_create_order', function ( $order, $data ) {
	foreach ( array( 'billing_custom_1', 'billing_custom_2' ) as $key ) {
		if ( ! empty( $_POST[ $key ] ) ) {
			$order->update_meta_data( $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
}, 10, 2 );
