<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Product gallery: main image + clickable thumbnails, with the same
 * borderless in-image arrows as the homepage hero slider. Falls back
 * to a plain single image (no thumbs/arrows) when there's only one photo.
 */
function dentalshop_render_product_gallery( $product ) {
	$featured_id = $product->get_image_id();
	$gallery_ids = $product->get_gallery_image_ids();
	$all_ids     = array_filter( array_merge( array( $featured_id ), $gallery_ids ) );

	if ( empty( $all_ids ) ) {
		echo wc_placeholder_img( 'dentalshop-square' );
		return;
	}

	$first_full = wp_get_attachment_image_url( $all_ids[0], 'large' );
	$first_original = wp_get_attachment_image_url( $all_ids[0], 'full' );
	?>
	<div class="slider-wrap">
		<div class="gallery-main">
			<img src="<?php echo esc_url( $first_full ); ?>" data-fullsrc="<?php echo esc_url( $first_original ); ?>" alt="<?php echo esc_attr( get_the_title( $product->get_id() ) ); ?>">
		</div>
		<?php if ( count( $all_ids ) > 1 ) : ?>
			<div class="hero-arrow right" onclick="galleryGo(-1)">‹</div>
			<div class="hero-arrow left" onclick="galleryGo(1)">›</div>
		<?php endif; ?>
	</div>
	<?php if ( count( $all_ids ) > 1 ) : ?>
		<div class="gallery-thumbs">
			<?php foreach ( $all_ids as $i => $id ) :
				$full  = wp_get_attachment_image_url( $id, 'large' );
				$original = wp_get_attachment_image_url( $id, 'full' );
				$thumb = wp_get_attachment_image( $id, 'thumbnail' );
				?>
				<div class="thumb <?php echo 0 === $i ? 'active' : ''; ?>" data-fullsrc="<?php echo esc_url( $full ); ?>" data-originalsrc="<?php echo esc_url( $original ); ?>">
					<?php echo $thumb; ?>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif;
}

/**
 * Trust-badge row under the add-to-cart button — 4 items with inline
 * SVG icons (no icon font library needed). Only the first item's text
 * ("ارسال سریع") is admin-editable (تنظیمات فروشگاه); the other three
 * are fixed.
 */
function dentalshop_render_trust_mini_row() {
	$settings = dentalshop_get_settings();
	$icons = array(
		'truck'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="6" width="14" height="11"/><path d="M15 10h4l3 3v4h-7z"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/></svg>',
		'shield' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.5 8.5 8 11 4.5-2.5 8-6 8-11V5z"/><path d="M9 12l2 2 4-4"/></svg>',
		'headset'=> '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 14v-2a9 9 0 0 1 18 0v2"/><path d="M21 15a2 2 0 0 1-2 2h-1v-6h1a2 2 0 0 1 2 2z"/><path d="M3 15a2 2 0 0 0 2 2h1v-6H5a2 2 0 0 0-2 2z"/></svg>',
		'rotate' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>',
	);
	$items = array(
		array( 'icon' => 'truck',   'label' => $settings['trust_shipping_label'] ?: 'ارسال سریع' ),
		array( 'icon' => 'shield',  'label' => 'ضمانت اصالت کالا' ),
		array( 'icon' => 'headset', 'label' => 'پشتیبانی فنی' ),
		array( 'icon' => 'rotate',  'label' => 'ضمانت بازگشت وجه' ),
	);
	echo '<div class="trust-mini-row">';
	foreach ( $items as $item ) {
		if ( empty( $item['label'] ) ) continue;
		echo '<div class="trust-mini"><i>' . $icons[ $item['icon'] ] . '</i><span>' . esc_html( $item['label'] ) . '</span></div>';
	}
	echo '</div>';
}
