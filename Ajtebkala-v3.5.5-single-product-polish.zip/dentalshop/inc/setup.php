<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Theme setup.
 */
function dentalshop_setup() {
	load_theme_textdomain( 'dentalshop', DENTALSHOP_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
	) );
	add_theme_support( 'custom-logo', array(
		'height'      => 60,
		'width'       => 220,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'responsive-embeds' );

	// WooCommerce.
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	// Image sizes used across the theme (product tiles, banners, categories).
	add_image_size( 'dentalshop-square', 600, 600, true );   // product tiles, category tiles
	add_image_size( 'dentalshop-banner-wide', 1600, 686, true ); // hero slides (21:9)
	add_image_size( 'dentalshop-banner-tall', 700, 500, true );  // side banners

	register_nav_menus( array(
		'topbar'  => __( 'Topbar Menu (خانه، تماس با ما، ...)', 'dentalshop' ),
		'mega'    => __( 'Mega Menu (دسته‌بندی محصولات)', 'dentalshop' ),
		'footer'  => __( 'Footer Menu', 'dentalshop' ),
		'mobile'  => __( 'Mobile Hamburger Menu', 'dentalshop' ),
	) );
}
add_action( 'after_setup_theme', 'dentalshop_setup' );

/**
 * Widget areas: 3 footer columns (the 4th footer "column" — trust badges —
 * is its own repeatable option, see inc/customizer.php).
 */
function dentalshop_widgets_init() {
	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar( array(
			/* translators: %d: footer column number */
			'name'          => sprintf( __( 'Footer Column %d', 'dentalshop' ), $i ),
			'id'            => 'footer-' . $i,
			'before_widget' => '<div class="widget">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4>',
			'after_title'   => '</h4>',
		) );
	}
}
add_action( 'widgets_init', 'dentalshop_widgets_init' );

/**
 * WordPress has a known behavior on a fresh install / first theme
 * activation: it auto-populates the FIRST available widget area with a
 * handful of default widgets (Search, Recent Posts, Archives,
 * Categories, Meta) so a brand-new site isn't completely empty. Since
 * our footer columns are the only registered widget areas, that
 * default content lands there — looking like a bug ("چرا این‌ها
 * اینجان؟") when really it's WordPress's own onboarding behavior. Wipe
 * it once on activation so the footer starts genuinely empty.
 */
add_action( 'after_switch_theme', function () {
	$known_default_widgets = array( 'search', 'recent-posts', 'archives', 'categories', 'meta', 'recent-comments' );
	$assignments = get_option( 'sidebars_widgets', array() );
	$changed = false;

	foreach ( array( 'footer-1', 'footer-2', 'footer-3' ) as $sidebar_id ) {
		if ( empty( $assignments[ $sidebar_id ] ) ) continue;
		$only_defaults = true;
		foreach ( $assignments[ $sidebar_id ] as $widget_id ) {
			$base = preg_replace( '/-\d+$/', '', $widget_id );
			if ( ! in_array( $base, $known_default_widgets, true ) ) { $only_defaults = false; break; }
		}
		if ( $only_defaults ) {
			$assignments[ $sidebar_id ] = array();
			$changed = true;
		}
	}

	if ( $changed ) update_option( 'sidebars_widgets', $assignments );
} );

/**
 * Full header height, tracked live on the front end via ResizeObserver
 * (assets/js/main.js) so the mega-panel and search-suggest panel always
 * sit exactly below the header — including when WordPress's own admin
 * toolbar pushes everything down for logged-in admins.
 */
