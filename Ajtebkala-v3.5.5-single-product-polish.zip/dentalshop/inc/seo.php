<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Lightweight Open Graph tags for products and posts — only output when
 * no SEO plugin is already handling this (Yoast, RankMath, All in One
 * SEO, SEOPress all add their own, richer versions; adding ours on top
 * would create duplicate/conflicting tags).
 */
function dentalshop_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

add_action( 'wp_head', function () {
	if ( dentalshop_seo_plugin_active() || is_admin() ) return;

	if ( is_singular( 'product' ) ) {
		global $product;
		if ( ! $product instanceof WC_Product ) $product = wc_get_product( get_the_ID() );
		if ( ! $product ) return;
		$image_id  = $product->get_image_id();
		$image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : '';
		?>
		<meta property="og:type" content="product">
		<meta property="og:title" content="<?php echo esc_attr( $product->get_name() ); ?>">
		<meta property="og:description" content="<?php echo esc_attr( wp_strip_all_tags( $product->get_short_description() ?: $product->get_description() ) ); ?>">
		<meta property="og:url" content="<?php echo esc_url( $product->get_permalink() ); ?>">
		<?php if ( $image_url ) : ?><meta property="og:image" content="<?php echo esc_url( $image_url ); ?>"><?php endif; ?>
		<meta property="product:price:amount" content="<?php echo esc_attr( $product->get_price() ); ?>">
		<meta property="product:price:currency" content="<?php echo esc_attr( get_woocommerce_currency() ); ?>">
		<?php
	} elseif ( is_singular( 'post' ) ) {
		?>
		<meta property="og:type" content="article">
		<meta property="og:title" content="<?php the_title_attribute(); ?>">
		<meta property="og:description" content="<?php echo esc_attr( wp_strip_all_tags( get_the_excerpt() ) ); ?>">
		<meta property="og:url" content="<?php the_permalink(); ?>">
		<?php if ( has_post_thumbnail() ) : ?>
			<meta property="og:image" content="<?php echo esc_url( get_the_post_thumbnail_url( get_the_ID(), 'large' ) ); ?>">
		<?php endif; ?>
		<?php
	}
}, 5 );
