<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Product category "Description" is a plain textarea by default. This
 * swaps it for a full wp_editor() (headings, bold/italic, lists, links)
 * on both the Add and Edit category screens.
 */
add_action( 'product_cat_add_form_fields', 'dentalshop_category_description_editor_add' );
function dentalshop_category_description_editor_add() {
	?>
	<div class="form-field term-description-wrap">
		<label for="tag-description"><?php esc_html_e( 'توضیحات', 'dentalshop' ); ?></label>
		<?php
		wp_editor( '', 'tag-description-editor', array(
			'textarea_name' => 'description',
			'media_buttons' => false,
			'textarea_rows' => 8,
			'teeny'         => false,
		) );
		?>
		<p><?php esc_html_e( 'در صفحه‌ی فروشگاه فقط ۲-۳ خط اول نمایش داده می‌شود؛ بقیه با دکمه‌ی «نمایش بیشتر» باز می‌شود.', 'dentalshop' ); ?></p>
	</div>
	<script>
	// hide the plain-text "description" field WooCommerce/WP renders by
	// default and keep only our WYSIWYG one, without removing the real
	// #description field the editor is synced to (still submits normally).
	document.addEventListener('DOMContentLoaded', function () {
		var plain = document.querySelector('.term-description-wrap textarea#description');
		if (plain && plain.id === 'description') { /* wp_editor already reuses this id via textarea_name mapping */ }
	});
	</script>
	<?php
}

add_action( 'product_cat_edit_form_fields', 'dentalshop_category_description_editor_edit', 10, 2 );
function dentalshop_category_description_editor_edit( $term ) {
	?>
	<tr class="form-field term-description-wrap">
		<th scope="row"><label for="description"><?php esc_html_e( 'توضیحات', 'dentalshop' ); ?></label></th>
		<td>
			<?php
			wp_editor( wp_kses_post( $term->description ), 'description', array(
				'textarea_name' => 'description',
				'media_buttons' => false,
				'textarea_rows' => 8,
				'teeny'         => false,
			) );
			?>
			<p class="description"><?php esc_html_e( 'در صفحه‌ی فروشگاه فقط ۲-۳ خط اول نمایش داده می‌شود؛ بقیه با دکمه‌ی «نمایش بیشتر» باز می‌شود.', 'dentalshop' ); ?></p>
		</td>
	</tr>
	<?php
}

/**
 * WordPress runs term descriptions through wp_kses (a plain-text-ish
 * filter set) by default when saving, which strips headings/formatting.
 * Allow the same rich set of tags/attributes our WYSIWYG editor produces.
 */
add_filter( 'pre_term_description', function ( $description ) {
	return wp_kses_post( $description );
}, 20 );
