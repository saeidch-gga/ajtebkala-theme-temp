<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Ajtebkala order tools:
 * - payment method column in WooCommerce order lists
 * - invoice / postal-label row actions
 * - secure print views for invoice and label
 */

function ajtebkala_jalali_datetime( $timestamp = null, $with_time = true ) {
	$timestamp = $timestamp ?: current_time( 'timestamp' );
	if ( function_exists( 'jdate' ) ) {
		return jdate( $with_time ? 'Y-m-d H:i' : 'Y-m-d', $timestamp );
	}
	$g_y = (int) gmdate( 'Y', $timestamp ); $g_m = (int) gmdate( 'n', $timestamp ); $g_d = (int) gmdate( 'j', $timestamp );
	$g_days = array( 0,31,59,90,120,151,181,212,243,273,304,334 );
	$gy2 = ( $g_m > 2 ) ? ( $g_y + 1 ) : $g_y;
	$days = 355666 + ( 365 * $g_y ) + floor( ( $gy2 + 3 ) / 4 ) - floor( ( $gy2 + 99 ) / 100 ) + floor( ( $gy2 + 399 ) / 400 ) + $g_d + $g_days[ $g_m - 1 ];
	$jy = -1595 + ( 33 * floor( $days / 12053 ) );
	$days %= 12053;
	$jy += 4 * floor( $days / 1461 );
	$days %= 1461;
	if ( $days > 365 ) { $jy += floor( ( $days - 1 ) / 365 ); $days = ( $days - 1 ) % 365; }
	if ( $days < 186 ) { $jm = 1 + floor( $days / 31 ); $jd = 1 + ( $days % 31 ); }
	else { $jm = 7 + floor( ( $days - 186 ) / 30 ); $jd = 1 + ( ( $days - 186 ) % 30 ); }
	$result = sprintf( '%04d-%02d-%02d', $jy, $jm, $jd );
	return $with_time ? $result . ' ' . gmdate( 'H:i', $timestamp ) : $result;
}

function ajtebkala_seller_details() {
	return array(
		'name'    => 'عاج طب کالا',
		'title'   => 'عاج طب کالا | خرید و فروش ابزار و تجهیزات دندانپزشکی',
		'website' => 'https://ajtebkala.com',
		'phones'  => '۰۹۰۳۲۳۰۷۵۷۵ - ۰۲۱۶۶۷۰۷۵۷۵',
		'address' => 'تهران، ضلع شرقی بزرگراه نواب، جنب پل مرتضوی، پاساژ تجهیزات دندانپزشکی ایران (دنتال سنتر)، پلاک ۵۶ فروشگاه عاج طب',
	);
}

/**
 * Return address pieces in the display order used by Ajtebkala prints:
 * province, city, then street address. Shipping is preferred whenever it
 * actually contains an address; otherwise billing is used.
 */
function ajtebkala_get_order_address_parts( $order ) {
	$use_shipping = (bool) ( $order->get_shipping_address_1() || $order->get_shipping_city() || $order->get_shipping_state() );
	$prefix = $use_shipping ? 'shipping' : 'billing';
	$country = $order->{'get_' . $prefix . '_country'}();
	$state   = $order->{'get_' . $prefix . '_state'}();
	$city    = $order->{'get_' . $prefix . '_city'}();
	$address = trim( implode( '، ', array_filter( array(
		$order->{'get_' . $prefix . '_address_1'}(),
		$order->{'get_' . $prefix . '_address_2'}(),
	) ) ) );

	if ( $state && $country && function_exists( 'WC' ) && WC()->countries ) {
		$states = WC()->countries->get_states( $country );
		if ( is_array( $states ) && isset( $states[ $state ] ) ) {
			$state = $states[ $state ];
		}
	}

	return array(
		'province' => trim( (string) $state ),
		'city'     => trim( (string) $city ),
		'address'  => $address,
		'postcode' => trim( (string) $order->{'get_' . $prefix . '_postcode'}() ),
		'prefix'   => $prefix,
	);
}

function ajtebkala_order_address_line( $order ) {
	$parts = ajtebkala_get_order_address_parts( $order );
	return implode( '، ', array_filter( array( $parts['province'], $parts['city'], $parts['address'] ) ) );
}

function ajtebkala_order_list_columns( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'order_status' === $key ) {
			$new['ajteb_payment_method'] = 'روش پرداخت';
		}
	}
	if ( ! isset( $new['ajteb_payment_method'] ) ) {
		$new['ajteb_payment_method'] = 'روش پرداخت';
	}
	return $new;
}
add_filter( 'manage_edit-shop_order_columns', 'ajtebkala_order_list_columns', 30 );
add_filter( 'manage_woocommerce_page_wc-orders_columns', 'ajtebkala_order_list_columns', 30 );

function ajtebkala_render_order_list_column( $column, $post_or_order ) {
	if ( 'ajteb_payment_method' !== $column ) return;
	$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order );
	if ( ! $order ) {
		echo '—';
		return;
	}
	$title = $order->get_payment_method_title();
	echo $title ? esc_html( $title ) : '<span style="color:#999">—</span>';
}
add_action( 'manage_shop_order_posts_custom_column', 'ajtebkala_render_order_list_column', 30, 2 );
add_action( 'manage_woocommerce_page_wc-orders_custom_column', 'ajtebkala_render_order_list_column', 30, 2 );

function ajtebkala_order_row_actions( $actions, $order ) {
	if ( ! $order instanceof WC_Order ) return $actions;
	$id = $order->get_id();
	$actions['ajteb_invoice'] = array(
		'url'    => wp_nonce_url( admin_url( 'admin-post.php?action=ajteb_print_invoice&order_id=' . $id ), 'ajteb_print_order_' . $id ),
		'name'   => 'چاپ فاکتور',
		'action' => 'ajteb_invoice',
	);
	$actions['ajteb_label'] = array(
		'url'    => wp_nonce_url( admin_url( 'admin-post.php?action=ajteb_print_label&order_id=' . $id ), 'ajteb_print_order_' . $id ),
		'name'   => 'چاپ برچسب پستی',
		'action' => 'ajteb_label',
	);
	return $actions;
}
add_filter( 'woocommerce_admin_order_actions', 'ajtebkala_order_row_actions', 30, 2 );

function ajtebkala_print_order_guard() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'شما اجازه دسترسی به این صفحه را ندارید.', 'dentalshop' ), 403 );
	}
	$order_id = absint( $_GET['order_id'] ?? 0 );
	if ( ! $order_id || ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'ajteb_print_order_' . $order_id ) ) {
		wp_die( esc_html__( 'درخواست نامعتبر است.', 'dentalshop' ), 400 );
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		wp_die( esc_html__( 'سفارش پیدا نشد.', 'dentalshop' ), 404 );
	}
	return $order;
}

function ajtebkala_admin_print_header( $title, $type = 'invoice' ) {
	$label = 'invoice' === $type ? 'فاکتور' : 'برچسب پستی';
	?><!doctype html>
	<html <?php language_attributes(); ?> dir="rtl">
	<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title><?php echo esc_html( $title ); ?></title>
	<style>
	@font-face{font-family:AjtebPrint;src:url('<?php echo esc_url( DENTALSHOP_URI . '/assets/fonts/Vazirmatn-RD-Regular.woff2' ); ?>') format('woff2');font-weight:400;font-display:swap}
	@font-face{font-family:AjtebPrint;src:url('<?php echo esc_url( DENTALSHOP_URI . '/assets/fonts/Vazirmatn-Bold.woff2' ); ?>') format('woff2');font-weight:700;font-display:swap}
	*{box-sizing:border-box}body{margin:0;background:#f5f5f5;color:#111;font-family:AjtebPrint,Arial,sans-serif;font-size:13px}.print-wrap{max-width:1200px;margin:30px auto;background:#fff;padding:24px;box-shadow:0 4px 24px rgba(0,0,0,.08)}
	.print-actions{display:flex;justify-content:center;gap:8px;margin:0 auto 18px}.print-actions button{border:0;background:#ff604d;color:#fff;padding:10px 18px;border-radius:4px;font:inherit;cursor:pointer}.print-actions .back{background:#666}
	@media print{body{background:#fff}.print-wrap{max-width:none;margin:0;padding:0;box-shadow:none}.print-actions{display:none}}
	</style>
	</head><body><div class="print-wrap">
	<div class="print-actions"><button type="button" onclick="window.print()">چاپ <?php echo esc_html( $label ); ?></button><button type="button" class="back" onclick="history.back()">بازگشت</button></div>
	<?php
}

function ajtebkala_admin_print_footer() {
	?></div></body></html><?php
}

function ajtebkala_print_invoice() {
	$order = ajtebkala_print_order_guard();
	$seller = ajtebkala_seller_details();
	$billing_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
	$shipping_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
	$buyer_name = $billing_name ?: $shipping_name;
	$address_parts = ajtebkala_get_order_address_parts( $order );
	$buyer_address = ajtebkala_order_address_line( $order );
	ajtebkala_admin_print_header( 'فاکتور سفارش #' . $order->get_order_number(), 'invoice' );
	?>
	<style>
	.invoice-head{border:1px solid #2f80c9;margin-bottom:18px}.invoice-head-top{display:grid;grid-template-columns:1.2fr 1fr;min-height:110px}.invoice-seller,.invoice-meta{padding:16px;line-height:2}.invoice-seller{border-left:1px solid #222;text-align:right}.invoice-seller h2{font-size:18px;margin:12px 0 8px}.invoice-seller p,.invoice-meta p{margin:2px 0}.invoice-address{background:#cfe5f5;border-top:1px solid #2f80c9;padding:10px 14px;font-weight:600}.buyer-box{background:#cfe5f5;border:1px solid #2f80c9;padding:10px 14px;margin-bottom:18px;line-height:2;font-weight:600}.invoice-table{width:100%;border-collapse:collapse}.invoice-table th,.invoice-table td{border:1px solid #2f80c9;padding:10px;text-align:center}.invoice-table th{background:#cfe5f5;font-weight:700}.invoice-table td.product{text-align:right}.invoice-totals{width:42%;min-width:420px;margin-top:18px;margin-right:auto;border-collapse:collapse}.invoice-totals th,.invoice-totals td{border:1px solid #2f80c9;padding:10px}.invoice-totals th{background:#cfe5f5;text-align:right}.invoice-totals td{text-align:left}.invoice-note{margin-top:14px;color:#666}
	@media(max-width:700px){.invoice-head-top{grid-template-columns:1fr}.invoice-seller{border-left:0;border-bottom:1px solid #222}.invoice-totals{width:100%;min-width:0}.invoice-table{font-size:11px}}
	</style>
	<div class="invoice-head">
		<div class="invoice-head-top">
			<div class="invoice-seller">
				<strong>فروشنده</strong>
				<h2><?php echo esc_html( $seller['title'] ); ?></h2>
				<p><strong>وبسایت:</strong> <?php echo esc_html( $seller['website'] ); ?></p>
				<p><strong>تلفن:</strong> <?php echo esc_html( $seller['phones'] ); ?></p>
			</div>
			<div class="invoice-meta">
				<p><strong>تاریخ چاپ:</strong> <?php echo esc_html( ajtebkala_jalali_datetime( current_time( 'timestamp' ) ) ); ?></p>
				<p><strong>شناسه سفارش:</strong> <?php echo esc_html( $order->get_order_number() ); ?></p>
		</div>
		</div>
		<div class="invoice-address"><strong>آدرس:</strong> <?php echo esc_html( $seller['address'] ); ?></div>
	</div>

	<div class="buyer-box">
		<strong>خریدار:</strong> <?php echo esc_html( $buyer_name ?: '—' ); ?>
		&nbsp;&nbsp;&nbsp; <strong>کدپستی:</strong> <?php echo esc_html( $order->get_billing_postcode() ?: $order->get_shipping_postcode() ?: '—' ); ?>
		&nbsp;&nbsp;&nbsp; <strong>تلفن:</strong> <?php echo esc_html( $order->get_billing_phone() ?: '—' ); ?>
		&nbsp;&nbsp;&nbsp; <strong>تاریخ سفارش:</strong> <?php echo esc_html( $order->get_date_created() ? ajtebkala_jalali_datetime( $order->get_date_created()->getTimestamp() ) : '—' ); ?>
		<?php if ( $buyer_address ) : ?><br><strong>نشانی:</strong> <?php echo esc_html( $buyer_address ); ?><?php endif; ?>
	</div>

	<table class="invoice-table">
		<thead><tr><th>ردیف</th><th>شناسه</th><th>محصول</th><th>قیمت</th><th>مبلغ تخفیف</th><th>تعداد</th><th>مبلغ کل</th></tr></thead>
		<tbody>
		<?php $i = 1; foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) :
			$product = $item->get_product();
			$qty = (float) $item->get_quantity();
			$line_total = (float) $item->get_total();
			$line_subtotal = (float) $item->get_subtotal();
			$discount = max( 0, $line_subtotal - $line_total );
		?>
		<tr>
			<td><?php echo esc_html( $i++ ); ?></td>
			<td><?php echo esc_html( $product ? $product->get_sku() : $item->get_product_id() ); ?></td>
			<td class="product"><?php echo esc_html( $item->get_name() ); ?></td>
			<td><?php echo wp_kses_post( wc_price( $qty > 0 ? $line_subtotal / $qty : $line_subtotal ) ); ?></td>
			<td><?php echo wp_kses_post( wc_price( $discount ) ); ?></td>
			<td><?php echo esc_html( wc_format_decimal( $qty, 0 ) ); ?></td>
			<td><?php echo wp_kses_post( wc_price( $line_total ) ); ?></td>
		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p><strong>تعداد کل:</strong> <?php echo esc_html( $order->get_item_count() ); ?></p>
	<table class="invoice-totals">
		<tr><th>مبلغ کل</th><td><?php echo wp_kses_post( wc_price( (float) $order->get_subtotal() ) ); ?></td></tr>
		<tr><th>مبلغ حمل و نقل</th><td><?php echo wp_kses_post( wc_price( (float) $order->get_shipping_total() ) ); ?></td></tr>
		<tr><th>مبلغ نهایی</th><td><strong><?php echo wp_kses_post( wc_price( (float) $order->get_total() ) ); ?></strong></td></tr>
	</table>
	<p class="invoice-note"><strong>روش پرداخت:</strong> <?php echo esc_html( $order->get_payment_method_title() ?: '—' ); ?></p>
	<?php
	ajtebkala_admin_print_footer();
}
add_action( 'admin_post_ajteb_print_invoice', 'ajtebkala_print_invoice' );

function ajtebkala_print_label() {
	$order = ajtebkala_print_order_guard();
	$seller = ajtebkala_seller_details();
	$recipient = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
	if ( ! $recipient ) $recipient = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
	$address_parts = ajtebkala_get_order_address_parts( $order );
	$address = ajtebkala_order_address_line( $order );
	ajtebkala_admin_print_header( 'برچسب پستی سفارش #' . $order->get_order_number(), 'label' );
	?>
	<style>
	.label-sheet{border:12px solid transparent;border-image:repeating-linear-gradient(135deg,#e21b16 0 22px,#fff 22px 30px,#2e9ce6 30px 52px,#fff 52px 60px) 12;padding:0}.label-top{display:grid;grid-template-columns:1fr 1fr;border:1px solid #222;direction:ltr}.label-seller,.label-recipient{direction:rtl}.label-seller,.label-recipient{padding:22px;min-height:255px;line-height:2}.label-seller{border-left:1px solid #222}.label-seller h2{font-size:18px;margin:30px 0 8px}.label-seller p,.label-recipient p{margin:2px 0}.label-items{border:1px solid #222;border-top:0;padding:18px 22px;min-height:110px;line-height:2}.label-order-id{border:1px solid #222;border-top:0;padding:14px;text-align:center;font-weight:700;font-size:16px}.label-actions{margin-top:14px}
	@media(max-width:700px){.label-top{grid-template-columns:1fr}.label-seller{border-left:0;border-bottom:1px solid #222}}
	</style>
	<div class="label-sheet">
		<div class="label-top">
			<div class="label-seller">
				<hr>
				<h2><?php echo esc_html( $seller['title'] ); ?></h2>
				<p><strong>آدرس:</strong> <?php echo esc_html( $seller['address'] ); ?></p>
				<p><strong>تلفن:</strong> <?php echo esc_html( $seller['phones'] ); ?></p>
				<p><strong>وبسایت:</strong> <?php echo esc_html( $seller['website'] ); ?></p>
			</div>
			<div class="label-recipient">
				<p><strong>گیرنده:</strong> <?php echo esc_html( $recipient ?: '—' ); ?></p>
				<?php if ( $address ) : ?><p><strong>آدرس:</strong> <?php echo esc_html( $address ); ?></p><?php endif; ?>
				<?php if ( $order->get_date_created() ) : ?><p><strong>تاریخ سفارش:</strong> <?php echo esc_html( ajtebkala_jalali_datetime( $order->get_date_created()->getTimestamp() ) ); ?></p><?php endif; ?>
				<?php $customer_note = trim( (string) $order->get_customer_note() ); if ( $customer_note ) : ?>
				<p><strong>یادداشت مشتری:</strong> <?php echo nl2br( esc_html( $customer_note ) ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="label-items">
			<?php $i=1; foreach ( $order->get_items( 'line_item' ) as $item ) : ?>
			<div><?php echo esc_html( $i++ . ' - ' . $item->get_name() . ' | تعداد: ' . $item->get_quantity() ); ?></div>
			<?php endforeach; ?>
		</div>
		<div class="label-order-id">شناسه سفارش: <?php echo esc_html( $order->get_order_number() ); ?></div>
	</div>
	<?php
	ajtebkala_admin_print_footer();
}
add_action( 'admin_post_ajteb_print_label', 'ajtebkala_print_label' );
