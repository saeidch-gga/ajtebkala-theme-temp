<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Renders the "mega" location menu. Build it normally under
 * Appearance → Menus by nesting items:
 *
 *   تجهیزات دندانپزشکی            (depth 0 — nav bar item)
 *   └─ یونیت دندانپزشکی            (depth 1 — becomes a mega-panel column,
 *      ├─ یونیت ایرانی              its own link stays clickable as the
 *      └─ یونیت وارداتی              column heading)
 *   └─ کمپرسور و ساکشن
 *      ├─ ...
 *
 * A depth-0 item with no children just renders as a plain nav link
 * (e.g. "لیست قیمت محصولات") — the panel only appears when there's
 * something to put in it. Column count is whatever the editor nests;
 * the panel centers itself and bleeds full viewport width via CSS
 * (see .mega-panel in assets/css/main.css) — nothing here hardcodes a
 * column count, so it's fully adaptive.
 */
class DentalShop_Mega_Walker extends Walker_Nav_Menu {

	public function start_lvl( &$output, $depth = 0, $args = null ) {
		if ( 0 === $depth ) {
			$output .= '<div class="mega-panel">';
		} elseif ( 1 === $depth ) {
			$output .= '<div class="sub">'; // leaf-link list under a column heading
		}
	}

	public function end_lvl( &$output, $depth = 0, $args = null ) {
		if ( 0 === $depth ) {
			$output .= '</div><!-- /.mega-panel -->';
		} elseif ( 1 === $depth ) {
			$output .= '</div><!-- /.sub -->';
		}
	}

	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		$has_children = in_array( 'menu-item-has-children', $classes, true );
		$url  = esc_url( $item->url );
		$text = apply_filters( 'the_title', $item->title, $item->ID );

		if ( 0 === $depth ) {
			$item_class = 'mega-item' . ( $has_children ? '' : ' mega-item-simple' );
			$output .= '<div class="' . esc_attr( $item_class ) . '"><a href="' . $url . '">' . esc_html( $text ) . '</a>';
			// start_lvl (if any children) opens .mega-panel right after this
		} elseif ( 1 === $depth ) {
			$output .= '<div class="mega-col"><h4><a href="' . $url . '">' . esc_html( $text ) . '</a></h4>';
			// start_lvl (if any grandchildren) opens .sub right after this
			if ( ! $has_children ) {
				$output .= '</div><!-- /.mega-col (no leaf links) -->';
			}
		} else { // depth 2 — leaf link
			$output .= '<a href="' . $url . '">' . esc_html( $text ) . '</a>';
		}
	}

	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$classes      = empty( $item->classes ) ? array() : (array) $item->classes;
		$has_children = in_array( 'menu-item-has-children', $classes, true );

		if ( 0 === $depth ) {
			$output .= '</div><!-- /.mega-item -->';
		} elseif ( 1 === $depth && $has_children ) {
			$output .= '</div><!-- /.mega-col -->';
		}
		// depth 2: nothing to close, leaf <a> is self-contained
	}
}

/**
 * Renders the SAME 'mega' menu location as a mobile off-canvas accordion
 * (<details>/<summary> per top-level category) instead of the desktop
 * mega-panel — one menu in Appearance → Menus drives both.
 */
function dentalshop_render_mobile_menu_accordion( $menu_location = 'mega' ) {
	$locations = get_nav_menu_locations();
	if ( empty( $locations[ $menu_location ] ) ) return;

	$menu       = wp_get_nav_menu_object( $locations[ $menu_location ] );
	$menu_items = wp_get_nav_menu_items( $menu->term_id );
	if ( ! $menu_items ) return;

	// Build a depth-indexed tree keyed by parent ID.
	$tree = array();
	foreach ( $menu_items as $item ) {
		$tree[ $item->menu_item_parent ][] = $item;
	}

	$top_items = $tree[0] ?? array();
	foreach ( $top_items as $i => $top ) {
		$children = $tree[ $top->ID ] ?? array();
		if ( empty( $children ) ) {
			echo '<a href="' . esc_url( $top->url ) . '" class="mobile-cat mobile-cat-simple">' . esc_html( $top->title ) . '</a>';
			continue;
		}
		?>
		<details class="mobile-cat" <?php echo 0 === $i ? 'open' : ''; ?>>
			<summary><?php echo esc_html( $top->title ); ?></summary>
			<div class="sub">
				<a href="<?php echo esc_url( $top->url ); ?>"><b><?php esc_html_e( 'مشاهده همه', 'dentalshop' ); ?></b></a>
				<?php foreach ( $children as $col ) :
					$leaves = $tree[ $col->ID ] ?? array();
					if ( $leaves ) : ?>
						<strong class="mobile-col-head"><?php echo esc_html( $col->title ); ?></strong>
						<?php foreach ( $leaves as $leaf ) : ?>
							<a href="<?php echo esc_url( $leaf->url ); ?>"><?php echo esc_html( $leaf->title ); ?></a>
						<?php endforeach; ?>
					<?php else : ?>
						<a href="<?php echo esc_url( $col->url ); ?>"><?php echo esc_html( $col->title ); ?></a>
					<?php endif;
				endforeach; ?>
			</div>
		</details>
		<?php
	}
}
