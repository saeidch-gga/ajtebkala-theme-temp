<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Live product search suggestions dropdown (header search box).
 */
function dentalshop_ajax_search() {
	check_ajax_referer( 'dentalshop_ajax', 'nonce' );

	$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';
	if ( strlen( $term ) < 2 ) {
		wp_send_json( array() );
	}

	$products = wc_get_products( array(
		's'       => $term,
		'limit'   => 6,
		'status'  => 'publish',
	) );

	$results = array_map( function ( $product ) {
		return array(
			'url'   => $product->get_permalink(),
			'name'  => $product->get_name(),
			'price' => wp_strip_all_tags( $product->get_price_html() ),
			'image' => wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) ?: wc_placeholder_img_src( 'thumbnail' ),
		);
	}, $products );

	wp_send_json( $results );
}
add_action( 'wp_ajax_dentalshop_search', 'dentalshop_ajax_search' );
add_action( 'wp_ajax_nopriv_dentalshop_search', 'dentalshop_ajax_search' );
