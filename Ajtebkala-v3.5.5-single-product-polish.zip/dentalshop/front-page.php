<?php
/**
 * Homepage template.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();

$ds     = dentalshop_get_settings();
$slides = dentalshop_get_hero_slides();
$side_1 = dentalshop_get_banner_by_slot( 'side_1' );
$side_2 = dentalshop_get_banner_by_slot( 'side_2' );
$ad_full = dentalshop_get_banner_by_slot( 'ad_full' );
$mini_banners = dentalshop_get_mini_row_banners();
?>

<div class="wrap">

	<!-- HERO SLIDER + SIDE BANNERS -->
	<section>
		<div class="banner-row">
			<div class="slider-wrap">
				<div class="hero-slider" id="heroSlider">
					<?php if ( $slides ) : foreach ( $slides as $i => $slide ) :
						$link = get_post_meta( $slide->ID, '_ds_link', true ) ?: '#';
						$img  = get_the_post_thumbnail_url( $slide->ID, 'dentalshop-banner-wide' );
						?>
						<a href="<?php echo esc_url( $link ); ?>" class="hero-slide <?php echo 0 === $i ? 'active' : ''; ?>"
							<?php if ( $img ) : ?>style="background-image:url('<?php echo esc_url( $img ); ?>');background-size:cover;background-position:center;"<?php endif; ?>>
							<?php if ( ! $img ) : ?><span><?php echo esc_html( get_the_title( $slide ) ); ?></span><?php endif; ?>
						</a>
					<?php endforeach; else : ?>
						<div class="hero-slide active ph ph-1"><span><?php esc_html_e( 'اسلایدهای بنر اصلی را از پنل مدیریت اضافه کنید', 'dentalshop' ); ?></span></div>
					<?php endif; ?>
					<div class="hero-dots" id="heroDots"></div>
				</div>
				<div class="hero-arrow right" onclick="heroGo(-1)">‹</div>
				<div class="hero-arrow left" onclick="heroGo(1)">›</div>
			</div>
			<div class="banner-side-col">
				<?php foreach ( array( $side_1, $side_2 ) as $side ) : ?>
					<div class="banner-side">
						<?php if ( $side ) :
							$link = get_post_meta( $side->ID, '_ds_link', true ) ?: '#';
							?>
							<a href="<?php echo esc_url( $link ); ?>"><?php echo get_the_post_thumbnail( $side->ID, 'dentalshop-banner-tall' ); ?></a>
						<?php else : ?>
							<div class="ph ph-2"><?php esc_html_e( 'بنر کناری', 'dentalshop' ); ?></div>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- 6 CATEGORIES -->
	<?php if ( $ds['homepage_categories'] ) : ?>
	<section class="reveal">
		<div class="section-head"><h2><?php esc_html_e( 'دسته‌بندی‌های اصلی', 'dentalshop' ); ?></h2></div>
		<div class="cats-row">
			<?php foreach ( array_slice( $ds['homepage_categories'], 0, 6 ) as $cat_id ) :
				$term = get_term( $cat_id, 'product_cat' );
				if ( ! $term || is_wp_error( $term ) ) continue;
				$thumb_id = get_term_meta( $cat_id, 'thumbnail_id', true );
				?>
				<a href="<?php echo esc_url( get_term_link( $term ) ); ?>" class="cat-card">
					<div class="cat-img">
						<?php echo $thumb_id ? wp_get_attachment_image( $thumb_id, 'dentalshop-square' ) : ''; ?>
					</div>
					<span><?php echo esc_html( $term->name ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php endif; ?>

	<!-- GOLD OFFERS -->
	<?php if ( $ds['gold_product_tag'] ) :
		$gold_products = wc_get_products( array( 'tag' => array( $ds['gold_product_tag'] ), 'limit' => 12 ) );
		if ( $gold_products ) : ?>
	<div class="gold-section reveal">
		<div class="section-head">
			<h2>✦ <?php esc_html_e( 'پیشنهادات طلایی', 'dentalshop' ); ?></h2>
			<?php if ( $ds['gold_countdown_end'] ) : ?>
				<div class="timer" id="goldTimer" data-end="<?php echo esc_attr( strtotime( $ds['gold_countdown_end'] ) * 1000 ); ?>"><span>00</span>:<span>00</span>:<span>00</span></div>
			<?php endif; ?>
			<?php
			$gold_tag_term = get_term_by( 'slug', $ds['gold_product_tag'], 'product_tag' );
			if ( $gold_tag_term ) : ?>
				<a href="<?php echo esc_url( get_term_link( $gold_tag_term ) ); ?>" class="see-all"><?php esc_html_e( 'مشاهده همه ←', 'dentalshop' ); ?></a>
			<?php endif; ?>
		</div>
		<div class="slider-wrap">
			<div class="slider-arrow right" onclick="slide(this,-1)">‹</div>
			<div class="slider-arrow left" onclick="slide(this,1)">›</div>
			<div class="p-slider">
				<?php foreach ( $gold_products as $product ) : ?>
					<?php get_template_part( 'template-parts/product-tile', null, array( 'product' => $product ) ); ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<?php endif; endif; ?>

	<!-- PRODUCT SLIDER 1 -->
	<?php get_template_part( 'template-parts/homepage-slider', null, array(
		'title' => $ds['slider_1_title'], 'category' => $ds['slider_1_category'],
	) ); ?>

	<!-- 4-BANNER ROW -->
	<?php if ( $mini_banners ) : ?>
	<section class="reveal">
		<div class="mini-banner-row">
			<?php foreach ( $mini_banners as $mb ) :
				$link = get_post_meta( $mb->ID, '_ds_link', true ) ?: '#';
				?>
				<a href="<?php echo esc_url( $link ); ?>" class="mini-banner"><?php echo get_the_post_thumbnail( $mb->ID, 'dentalshop-banner-tall' ); ?></a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php endif; ?>

	<!-- PRODUCT SLIDER 2 -->
	<?php get_template_part( 'template-parts/homepage-slider', null, array(
		'title' => $ds['slider_2_title'], 'category' => $ds['slider_2_category'],
	) ); ?>

	<!-- FULL WIDTH AD BANNER -->
	<?php if ( $ad_full ) :
		$link = get_post_meta( $ad_full->ID, '_ds_link', true ) ?: '#'; ?>
	<section class="reveal">
		<a href="<?php echo esc_url( $link ); ?>" class="ad-banner"><?php echo get_the_post_thumbnail( $ad_full->ID, 'large' ); ?></a>
	</section>
	<?php endif; ?>

	<!-- PRODUCT SLIDER 3 -->
	<?php get_template_part( 'template-parts/homepage-slider', null, array(
		'title' => $ds['slider_3_title'], 'category' => $ds['slider_3_category'],
	) ); ?>

	<!-- ARTICLE SLIDER -->
	<?php
	$articles = get_posts( array( 'posts_per_page' => 8 ) );
	if ( $articles ) : ?>
	<section class="reveal frame-x">
		<div class="section-head"><h2><?php esc_html_e( 'مقالات و اخبار', 'dentalshop' ); ?></h2><a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="see-all"><?php esc_html_e( 'مشاهده همه ←', 'dentalshop' ); ?></a></div>
		<div class="slider-wrap">
			<div class="slider-arrow right" onclick="slide(this,-1)">‹</div>
			<div class="slider-arrow left" onclick="slide(this,1)">›</div>
			<div class="article-slider">
				<?php foreach ( $articles as $article ) : ?>
					<a href="<?php echo esc_url( get_permalink( $article ) ); ?>" class="a-card">
						<div class="a-img"><?php echo get_the_post_thumbnail( $article, 'medium' ); ?></div>
						<div class="a-body"><?php echo esc_html( get_the_title( $article ) ); ?></div>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

</div>

<?php get_footer(); ?>
