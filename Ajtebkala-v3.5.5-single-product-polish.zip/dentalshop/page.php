<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();

/**
 * Cart/checkout via shortcode on a plain Page: let the shortcode's own
 * template provide 100% of the chrome (title, breadcrumb, width) —
 * don't wrap it in this page template's narrower article layout, and
 * don't print a second title/breadcrumb above it.
 */
if ( is_cart() || is_checkout() ) {
	echo '<div class="wrap">';
	while ( have_posts() ) : the_post();
		the_content();
	endwhile;
	echo '</div>';
	get_footer();
	return;
}
?>
<div class="wrap" style="padding: 30px 0 60px;">
	<nav class="breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'dentalshop' ); ?></a><span>/</span>
		<span class="current"><?php the_title(); ?></span>
	</nav>
	<div class="frame-x">
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class(); ?>>
				<h1 class="page-title" style="margin-top:0;"><?php the_title(); ?></h1>
				<div class="entry-content" style="font-size:0.95rem; line-height:2; color:var(--ink);">
					<?php the_content(); ?>
				</div>
			</article>
		<?php endwhile; ?>
	</div>
</div>
<?php get_footer();
