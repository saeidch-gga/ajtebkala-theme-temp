# تم DentalShop — راهنمای راه‌اندازی

## پیش‌نیازها
- وردپرس ۶.۰ به بالا
- افزونه‌ی **ووکامرس** فعال (تم بدون آن کار نمی‌کند)
- زبان سایت: فارسی (برای راست‌به‌چپ خودکار — از تنظیمات › عمومی)
- (اختیاری ولی توصیه‌شده) افزونه‌های:
  - Advanced Shipping for WooCommerce (Jeroen Sormani)
  - Digits (ورود/عضویت با شماره موبایل)

## مراحل راه‌اندازی

1. **فعال‌سازی تم** از ظاهر ← تم‌ها.
2. **صفحات ووکامرس** را در ووکامرس ← تنظیمات ← عمومی ← پیشرفته بررسی کنید (فروشگاه/سبد خرید/پرداخت/حساب کاربری باید به‌صورت خودکار ساخته شده باشند).
3. **منوها** را در ظاهر ← منوها بسازید و به این جایگاه‌ها اختصاص دهید:
   - **Topbar Menu** — لینک‌های ساده (خانه، تماس با ما، ...)
   - **Mega Menu** — دسته‌بندی محصولات؛ آیتم‌ها را تودرتو بسازید:
     - سطح ۱: دسته‌ی اصلی (مثلاً «تجهیزات دندانپزشکی»)
       - سطح ۲: زیردسته (ستون مگامنو، مثلاً «یونیت دندانپزشکی»)
         - سطح ۳: لینک نهایی (مثلاً «یونیت ایرانی»)
   - **Footer Menu** — لینک‌های فوتر (اختیاری)
4. **ویجت‌های فوتر** را در ظاهر ← ویجت‌ها برای هرکدام از ۳ ستون فوتر تنظیم کنید (اختیاری).
5. **تنظیمات فروشگاه** (منوی ادمین «تنظیمات فروشگاه»):
   - متن معرفی فوتر
   - ۴ آیکون اعتماد فوتر (تصویر + لینک)
   - تا ۴ مورد «راه‌های ارتباطی با ما»
   - عنوان و دسته‌بندی هر یک از ۳ اسلایدر محصول صفحه‌ی اصلی
   - برچسب (تگ) محصول برای «پیشنهادات طلایی» + زمان پایان شمارش معکوس
   - انتخاب تا ۶ دسته‌بندی برای ردیف دسته‌های صفحه‌ی اصلی
6. **بنرهای صفحه‌ی اصلی** (منوی ادمین «اسلایدهای بنر اصلی» و زیرمنوی «بنرهای سایت»):
   - تا ۷ «اسلاید بنر اصلی» بسازید (هرکدام: تصویر شاخص + لینک)
   - در «بنرهای سایت»، برای هر بنر یک «جایگاه نمایش» انتخاب کنید: بنر کناری ۱، بنر کناری ۲، ردیف ۴ بنر (تا ۴ مورد)، یا بنر تبلیغاتی تمام‌عرض
7. **فیلدهای پرداخت** (منوی ادمین ووکامرس ← فیلدهای پرداخت): فیلدهای پیش‌فرض را فعال/غیرفعال یا اجباری/اختیاری کنید، یا تا ۲ فیلد سفارشی اضافه کنید.
8. **محصولات متغیر با سواچ رنگ:** برای این‌که یک ویژگی (attribute) به‌صورت سواچ دایره‌ای نمایش داده شود، نام آن باید شامل «رنگ» یا «color» باشد. رنگ هر گزینه را می‌توانید با ابزار developer یا افزونه‌ای که به ترم‌های ویژگی متا اضافه می‌کند، در فیلد term meta با کلید `product_attribute_color` ذخیره کنید (در غیر این صورت رنگ پیش‌فرض خاکستری نمایش داده می‌شود).

## نکات فنی

- **⚠️ صفحات سبد خرید و پرداخت باید شورت‌کد باشند، نه بلوک:** ووکامرس جدید به‌صورت پیش‌فرض این دو صفحه رو با «بلوک‌های سبد خرید/پرداخت» (Cart & Checkout Blocks) می‌سازه که کاملاً جدا از فایل‌های PHP این تمه و باعث می‌شه طراحی ما اصلاً اجرا نشه. حتماً وارد ویرایش این دو صفحه بشید، هر بلوکی که هست (Cart block / Checkout block) رو کامل حذف کنید و به‌جاش شورت‌کد `[woocommerce_cart]` و `[woocommerce_checkout]` رو بذارید.
- **پاک‌سازی فوتر از ویجت‌های پیش‌فرض وردپرس:** اگه قبل از این نسخه، تم رو یک‌بار فعال کرده باشید، ممکنه وردپرس خودکار چندتا ویجت پیش‌فرض (بایگانی، دسته‌ها و...) توی ستون‌های فوتر گذاشته باشه. این نسخه یک‌بار به‌صورت خودکار هنگام فعال‌سازی تم پاکش می‌کنه، ولی چون شما از قبل فعالش کرده بودید، لازمه یا از ظاهر ← ویجت‌ها دستی پاکش کنید، یا تم رو یک‌بار روی یه تم دیگه سوییچ کنید و دوباره برگردونید تا پاک‌سازی خودکار اجرا بشه.
- **فونت Vazirmatn** به‌صورت پیش‌فرض از Google Fonts لود می‌شود. برای بهترین امتیاز PageSpeed، فایل وریِبل فونت را از
  https://github.com/rastikerdar/vazirmatn دانلود و در `assets/fonts/Vazirmatn.woff2` قرار دهید، سپس در `inc/enqueue.php` مقدار `$self_host_font` را به `true` تغییر دهید.
- **دیجیتس:** این تم عمداً فایل `woocommerce/myaccount/form-login.php` را override نکرده تا فرم شماره‌موبایل+کد افزونه‌ی دیجیتس دست‌نخورده باقی بماند.
- **حمل‌ونقل پیشرفته:** روش‌های ارسال از طریق تابع اصلی ووکامرس (`wc_cart_totals_shipping_html`) نمایش داده می‌شوند تا هر افزونه‌ی حمل‌ونقلی (از جمله Advanced Shipping) بدون نیاز به تغییر، به‌درستی کار کند.
- **استایل پیش‌فرض ووکامرس کاملاً غیرفعال شده:** با فیلتر `woocommerce_enqueue_styles`، تا هیچ تداخلی بین طراحی این تم و ظاهر پیش‌فرض ووکامرس (رنگ بنفش دکمه‌ها، عرض نصفه‌نیمه‌ی فیلدها و...) پیش نیاد.

## چیزهایی که هنوز نیاز به تکمیل/بررسی دارند

- صفحه‌ی نتایج جستجو (`search.php`) و صفحه‌ی ۴۰۴ ساده و کاربردی هستند ولی جزو طراحی اصلی که با هم مرور کردیم نبودند — در صورت نیاز به هم‌سویی بیشتر با بقیه‌ی طراحی بگویید.
- بخش نظرات محصول از سیستم دیدگاه‌های پیش‌فرض وردپرس/ووکامرس استفاده می‌کند و ظاهرش هنوز کاملاً با استایل کارت‌های سایت هماهنگ نشده.
- تصویر بندانگشتی تم (screenshot.png) ساخته نشده — صرفاً روی نمایش تم در پنل مدیریت تأثیر دارد، نه عملکرد سایت.


## v1.2.0 UX update
- Fixed the mobile homepage category-row horizontal overflow caused by 45% cards plus a fixed gap.
- Added a dedicated mobile header cart button beside the logo, wired to the existing cart drawer and cart fragments.
- Kept the WooCommerce archive/shop content inside the shared bordered white frame; search/product archives already use the same frame system.
- Added a centered product-gallery lightbox with full-size originals, previous/next navigation, counter, Escape and backdrop close.
- Changed all percentage-sale badges to the site's gold treatment while preserving the gray sold-out badge.
- Improved logged-out My Account form styling for WooCommerce/Digits-style markup and small screens.
- Fixed the self-hosted Vazirmatn filename reference to match the font actually included in the theme package.


## v1.2.1 — Homepage overflow + archive frame/grid fix
- Replaced the homepage hero `50vh` side-square calculation with a container-based CSS Grid layout to eliminate horizontal overflow on tall/narrow desktop viewports.
- Kept mobile hero behavior responsive with an explicit two-column side-banner row.
- Made the WooCommerce archive product list an explicit responsive grid because WooCommerce default styles are disabled.
- Ensured the archive title, description, sorting toolbar, product grid, and pagination are all direct children of the same bordered/rounded archive frame.
