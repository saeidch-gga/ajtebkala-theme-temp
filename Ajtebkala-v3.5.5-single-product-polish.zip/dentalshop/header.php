<?php
/**
 * Header template.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header" id="siteHeader">

	<!-- row 1: topbar (desktop only) -->
	<?php if ( has_nav_menu( 'topbar' ) ) : ?>
	<div class="top-bar">
		<div class="top-bar-inner">
			<?php wp_nav_menu( array( 'theme_location' => 'topbar', 'container' => false, 'items_wrap' => '%3$s' ) ); ?>
		</div>
	</div>
	<?php endif; ?>

	<!-- row 2: logo / search / account+cart (space-between) -->
	<div class="mid-header">
		<div class="mid-header-inner">

			<button class="menu-toggle" id="menuToggle" aria-label="<?php esc_attr_e( 'فهرست دسته‌ها', 'dentalshop' ); ?>">
				<span class="bar"></span>
			</button>

			<div class="site-logo">
				<?php if ( has_custom_logo() ) : the_custom_logo(); else : ?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
				<?php endif; ?>
			</div>

			<!-- mobile-only cart: sits directly to the left of the logo -->
			<button class="mobile-header-cart" id="mobileHeaderCartTrigger" type="button" aria-label="<?php esc_attr_e( 'سبد خرید', 'dentalshop' ); ?>">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<path d="M3 6h2l2.4 12.1a2 2 0 0 0 2 1.6h8.4a2 2 0 0 0 2-1.6L22 8H6"/>
					<circle cx="9" cy="21" r="1"/><circle cx="18" cy="21" r="1"/>
				</svg>
				<span class="cart-count"><?php echo WC()->cart ? esc_html( WC()->cart->get_cart_contents_count() ) : 0; ?></span>
			</button>

			<div class="search-box">
				<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<input type="text" name="s" class="ds-search-input" placeholder="<?php esc_attr_e( 'جستجوی محصول...', 'dentalshop' ); ?>" autocomplete="off" id="dsSearchInput">
					<input type="hidden" name="post_type" value="product">
					<span class="icon">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
					</span>
				</form>
				<div class="search-suggest ds-search-suggest" id="dsSearchSuggest"></div>
			</div>

			<div class="header-icons">
				<?php if ( is_user_logged_in() ) : ?>
				<div class="icon-btn account-wrap">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>
					<span><?php esc_html_e( 'حساب من', 'dentalshop' ); ?></span>
					<div class="account-menu">
						<a href="<?php echo esc_url( wc_get_account_endpoint_url( 'dashboard' ) ); ?>"><?php esc_html_e( 'داشبورد', 'dentalshop' ); ?></a>
						<a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'سفارش‌ها', 'dentalshop' ); ?></a>
						<a href="<?php echo esc_url( wc_get_account_endpoint_url( 'edit-address' ) ); ?>"><?php esc_html_e( 'آدرس‌ها', 'dentalshop' ); ?></a>
						<a href="<?php echo esc_url( wc_logout_url() ); ?>"><?php esc_html_e( 'خروج', 'dentalshop' ); ?></a>
					</div>
				</div>
				<?php else : ?>
				<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="icon-btn">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>
					<span><?php esc_html_e( 'ورود / عضویت', 'dentalshop' ); ?></span>
				</a>
				<?php endif; ?>

				<div class="icon-btn" id="cartTrigger">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h2l2.4 12.1a2 2 0 0 0 2 1.6h8.4a2 2 0 0 0 2-1.6L22 8H6"/><circle cx="9" cy="21" r="1"/><circle cx="18" cy="21" r="1"/></svg>
					<span class="cart-count"><?php echo WC()->cart ? esc_html( WC()->cart->get_cart_contents_count() ) : 0; ?></span>
					<span><?php esc_html_e( 'سبد خرید', 'dentalshop' ); ?></span>
				</div>
			</div>
		</div>
	</div>

	<!-- mobile-only search row -->
	<div class="mobile-search-row">
		<div class="search-box">
			<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<input type="text" name="s" class="ds-search-input" placeholder="<?php esc_attr_e( 'جستجوی محصول...', 'dentalshop' ); ?>">
				<input type="hidden" name="post_type" value="product">
				<span class="icon">
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
				</span>
			</form>
			<div class="search-suggest ds-search-suggest"></div>
		</div>
	</div>

	<!-- row 3: adaptive mega menu (desktop only) -->
	<?php if ( has_nav_menu( 'mega' ) ) : ?>
	<nav class="mega-nav">
		<div class="mega-nav-inner">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'mega',
				'container'      => false,
				'items_wrap'     => '%3$s',
				'walker'         => new DentalShop_Mega_Walker(),
			) );
			?>
		</div>
	</nav>
	<?php endif; ?>
</header>

<!-- off-canvas mobile menu (same 'mega' menu, accordion layout) -->
<div class="mobile-menu" id="mobileMenu">
	<div class="mobile-menu-head">
		<strong><?php esc_html_e( 'دسته‌بندی محصولات', 'dentalshop' ); ?></strong>
		<span id="mobileMenuClose">✕</span>
	</div>
	<?php dentalshop_render_mobile_menu_accordion( has_nav_menu( 'mobile' ) ? 'mobile' : 'mega' ); ?>
</div>
<div class="overlay" id="menuOverlay"></div>

<!-- cart drawer -->
<div class="cart-drawer" id="cartDrawer">
	<div class="cart-drawer-head">
		<h3><?php esc_html_e( 'سبد خرید', 'dentalshop' ); ?> (<?php echo WC()->cart ? esc_html( WC()->cart->get_cart_contents_count() ) : 0; ?> <?php esc_html_e( 'کالا', 'dentalshop' ); ?>)</h3>
		<span class="cart-drawer-close" id="cartClose">✕</span>
	</div>
	<div class="cart-drawer-items" id="cartDrawerItems">
		<?php get_template_part( 'template-parts/cart-drawer-items' ); ?>
	</div>
	<div class="cart-drawer-foot">
		<div class="cart-subtotal">
			<span><?php esc_html_e( 'جمع کل:', 'dentalshop' ); ?></span>
			<b id="cartDrawerTotal"><?php echo WC()->cart ? wp_kses_post( WC()->cart->get_cart_subtotal() ) : ''; ?></b>
		</div>
		<div class="cart-actions">
			<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="btn btn-outline"><?php esc_html_e( 'سبد خرید', 'dentalshop' ); ?></a>
			<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="btn"><?php esc_html_e( 'پرداخت', 'dentalshop' ); ?></a>
		</div>
	</div>
</div>
<div class="overlay" id="cartOverlay"></div>
