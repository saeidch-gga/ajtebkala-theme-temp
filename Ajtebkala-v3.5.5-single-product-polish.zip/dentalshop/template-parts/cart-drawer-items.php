<?php
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! WC()->cart || WC()->cart->is_empty() ) {
	echo '<p class="cart-empty">' . esc_html__( 'سبد خرید شما خالی است.', 'dentalshop' ) . '</p>';
	return;
}

foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
	$product = $cart_item['data'];
	if ( ! $product || ! $product->exists() || $cart_item['quantity'] <= 0 ) continue;
	?>
	<div class="cart-line">
		<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="thumb"><?php echo $product->get_image( 'thumbnail' ); ?></a>
		<div class="info">
			<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="name"><?php echo esc_html( $product->get_name() ); ?></a>
			<div class="qty"><?php printf( esc_html__( 'تعداد: %s', 'dentalshop' ), esc_html( $cart_item['quantity'] ) ); ?></div>
		</div>
		<div class="price"><?php echo wp_kses_post( WC()->cart->get_product_subtotal( $product, $cart_item['quantity'] ) ); ?></div>
	</div>
	<?php
}
