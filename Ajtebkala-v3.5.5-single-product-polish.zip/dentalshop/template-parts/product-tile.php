<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** @var WC_Product $product */
$product = $args['product'] ?? null;
if ( ! $product ) return;
?>
<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="p-card">
	<div class="p-img">
		<?php echo $product->get_image( 'dentalshop-square' ); ?>
		<?php echo apply_filters( 'woocommerce_sale_flash', '', get_post( $product->get_id() ), $product ); ?>
	</div>
	<div class="p-body">
		<div class="p-name"><?php echo esc_html( $product->get_name() ); ?></div>
		<div class="p-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
	</div>
</a>
