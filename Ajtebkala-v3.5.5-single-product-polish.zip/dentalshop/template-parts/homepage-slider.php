<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$title    = $args['title'] ?? '';
$category = $args['category'] ?? 0;
if ( ! $title ) return;

$query_args = array( 'limit' => 12, 'status' => 'publish' );
if ( $category ) {
	$term = get_term( $category, 'product_cat' );
	if ( $term && ! is_wp_error( $term ) ) {
		$query_args['category'] = array( $term->slug );
	}
}
$products = wc_get_products( $query_args );
if ( ! $products ) return;
?>
<section class="reveal frame-x">
	<div class="section-head">
		<h2><?php echo esc_html( $title ); ?></h2>
		<?php if ( $category ) : ?><a href="<?php echo esc_url( get_term_link( (int) $category, 'product_cat' ) ); ?>" class="see-all"><?php esc_html_e( 'مشاهده همه ←', 'dentalshop' ); ?></a><?php endif; ?>
	</div>
	<div class="slider-wrap">
		<div class="slider-arrow right" onclick="slide(this,-1)">‹</div>
		<div class="slider-arrow left" onclick="slide(this,1)">›</div>
		<div class="p-slider">
			<?php foreach ( $products as $product ) : ?>
				<?php get_template_part( 'template-parts/product-tile', null, array( 'product' => $product ) ); ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
