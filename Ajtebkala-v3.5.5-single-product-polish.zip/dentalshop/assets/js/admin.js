jQuery(function ($) {
	$(document).on('click', '.ds-media-select', function (e) {
		e.preventDefault();
		var $wrap = $(this).closest('.ds-media-picker');
		var frame = wp.media({
			title: 'انتخاب تصویر',
			multiple: false,
			library: { type: 'image' },
		});
		frame.on('select', function () {
			var attachment = frame.state().get('selection').first().toJSON();
			$wrap.find('.ds-media-id').val(attachment.id);
			$wrap.find('.ds-media-preview').attr('src', attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url).show();
		});
		frame.open();
	});
});
