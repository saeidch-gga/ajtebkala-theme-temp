/* ---- header height tracking (robust fix for the mega-panel /
     search-suggest overlap bug): a ResizeObserver keeps --header-total
     in sync with the header's ACTUAL rendered height at all times —
     including after webfont swap, content wrap, or window resize —
     instead of measuring once and hoping it never changes. ---- */
  const headerEl = document.getElementById('siteHeader');
  function syncHeaderTotal(){
    // Use the header's actual bottom edge relative to the viewport —
    // not just its own height — so anything sitting above it (this
    // preview's banner, or WordPress's own admin toolbar for logged-in
    // admins on the real site) is automatically accounted for.
    const bottom = headerEl.getBoundingClientRect().bottom;
    document.documentElement.style.setProperty('--header-total', bottom + 'px');
  }
  const headerRO = new ResizeObserver(syncHeaderTotal);
  headerRO.observe(headerEl);
  window.addEventListener('scroll', syncHeaderTotal, { passive: true });
  syncHeaderTotal();

  /* ---- generic slider arrows ---- */
  function stepTrack(track, dir){
    const firstCard = track.querySelector('.p-card, .a-card');
    if (!firstCard) return;
    const cardStyle = getComputedStyle(track);
    const gap = parseFloat(cardStyle.columnGap || cardStyle.gap || 0) || 0;
    const amount = firstCard.getBoundingClientRect().width + gap;
    const maxScroll = track.scrollWidth - track.clientWidth;

    // loop back to the start once we've reached the end (and vice versa)
    if (dir > 0 && track.scrollLeft <= -maxScroll + 2) {
      track.scrollTo({ left: 0, behavior: 'smooth' });
      return;
    }
    if (dir < 0 && track.scrollLeft >= -2) {
      track.scrollTo({ left: -maxScroll, behavior: 'smooth' });
      return;
    }
    track.scrollBy({ left: dir * -amount, behavior: 'smooth' });
  }

  function slide(btn, dir){
    const wrap = btn.closest('.slider-wrap');
    const track = wrap.querySelector('.p-slider, .article-slider');
    stepTrack(track, dir);
  }

  /* ---- auto-rotate every product/article slider: one item every 4s,
     loops back to the start, pauses while the user is hovering/interacting ---- */
  document.querySelectorAll('.slider-wrap').forEach(wrap => {
    const track = wrap.querySelector('.p-slider, .article-slider');
    if (!track) return;
    let timer = setInterval(() => stepTrack(track, 1), 4000);
    wrap.addEventListener('mouseenter', () => clearInterval(timer));
    wrap.addEventListener('mouseleave', () => { timer = setInterval(() => stepTrack(track, 1), 4000); });
    // also pause while the user is actively dragging/scrolling it by hand
    track.addEventListener('touchstart', () => clearInterval(timer), { passive: true });
  });

  /* ---- hero banner slider: autoplay + arrows + dots ---- */
  (function(){
    const slider = document.getElementById('heroSlider');
    if (!slider) return; // only exists on the homepage — nothing after this IIFE should ever depend on it running
    const slides = Array.from(slider.querySelectorAll('.hero-slide'));
    const dotsWrap = document.getElementById('heroDots');
    let idx = 0, timer;

    slides.forEach((_, i) => {
      const d = document.createElement('span');
      if(i === 0) d.classList.add('active');
      d.addEventListener('click', () => goTo(i));
      dotsWrap.appendChild(d);
    });
    const dots = Array.from(dotsWrap.children);

    function render(){
      slides.forEach((s,i) => s.classList.toggle('active', i===idx));
      dots.forEach((d,i) => d.classList.toggle('active', i===idx));
    }
    function goTo(i){ idx = (i + slides.length) % slides.length; render(); restart(); }
    window.heroGo = (dir) => goTo(idx + dir);
    function restart(){
      clearInterval(timer);
      // NOTE: assumed a 4.5s autoplay interval with a 500ms fade transition
      // (a literal 500ms interval would flip slides almost too fast to read —
      // flag this if you actually want a half-second cycle).
      timer = setInterval(() => goTo(idx + 1), 4500);
    }
    restart();
  })();

  /* ---- mobile off-canvas menu ---- */
  const menuToggle = document.getElementById('menuToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  const menuOverlay = document.getElementById('menuOverlay');
  function closeMobileMenu(){
    mobileMenu.classList.remove('open');
    menuOverlay.classList.remove('open');
    menuToggle.classList.remove('open');
  }
  menuToggle.addEventListener('click', () => {
    mobileMenu.classList.add('open');
    menuOverlay.classList.add('open');
    menuToggle.classList.add('open');
  });
  document.getElementById('mobileMenuClose').addEventListener('click', closeMobileMenu);
  menuOverlay.addEventListener('click', () => { closeMobileMenu(); closeCart(); });

  /* ---- cart drawer ---- */
  const cartDrawer = document.getElementById('cartDrawer');
  const cartOverlay = document.getElementById('cartOverlay');
  function openCart(){ cartDrawer.classList.add('open'); cartOverlay.classList.add('open'); }
  function closeCart(){ cartDrawer.classList.remove('open'); cartOverlay.classList.remove('open'); }
  const cartTrigger = document.getElementById('cartTrigger');
  if (cartTrigger) cartTrigger.addEventListener('click', openCart);
  const mobileHeaderCart = document.getElementById('mobileHeaderCartTrigger');
  if (mobileHeaderCart) mobileHeaderCart.addEventListener('click', openCart);
  document.getElementById('mobileCartTab').addEventListener('click', (e) => { e.preventDefault(); openCart(); });
  document.getElementById('cartClose').addEventListener('click', closeCart);
  cartOverlay.addEventListener('click', closeCart);

  /* ---- scroll reveal ---- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

/* ---- single product: tabs (description / reviews) ---- */
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
  });
});

/* ---- single product: gallery thumbnails + centered lightbox ---- */
(function () {
  const gallery = document.querySelector('.product-gallery');
  if (!gallery) return;

  const mainImg = gallery.querySelector('.gallery-main img');
  const thumbs = Array.from(gallery.querySelectorAll('.gallery-thumbs .thumb'));
  if (!mainImg) return;

  const items = [];
  const addItem = (src, original) => {
    if (!src && !original) return;
    const key = original || src;
    if (!items.some(item => item.key === key)) items.push({ key, src: src || original, original: original || src, thumb: src || original });
  };
  addItem(mainImg.src, mainImg.dataset.fullsrc || mainImg.src);
  thumbs.forEach(t => addItem(t.dataset.fullsrc, t.dataset.originalsrc || t.dataset.fullsrc));

  let current = 0;

  const lightbox = document.createElement('div');
  lightbox.className = 'ds-lightbox';
  lightbox.setAttribute('role', 'dialog');
  lightbox.setAttribute('aria-modal', 'true');
  lightbox.setAttribute('aria-label', 'نمایش بزرگ تصویر محصول');
  lightbox.innerHTML = `
    <button type="button" class="ds-lightbox-close" aria-label="بستن">×</button>
    <button type="button" class="ds-lightbox-prev" aria-label="تصویر قبلی">‹</button>
    <img alt="">
    <button type="button" class="ds-lightbox-next" aria-label="تصویر بعدی">›</button>
    <span class="ds-lightbox-counter"></span>
  `;
  document.body.appendChild(lightbox);

  const lbImg = lightbox.querySelector('img');
  const counter = lightbox.querySelector('.ds-lightbox-counter');

  function preloadNeighbors(){
    if (!items.length) return;
    [current-1,current+1].forEach(i=>{
      const item=items[(i+items.length)%items.length];
      if (!item) return;
      const img=new Image();
      img.src=item.original;
    });
  }

  function renderLightbox(index) {
    if (!items.length) return;
    current = (index + items.length) % items.length;
    lbImg.src = items[current].original;
    lbImg.alt = mainImg.alt || document.title;
    counter.textContent = `${current + 1} / ${items.length}`;

    thumbs.forEach((t, i) => t.classList.toggle('active', i === current));

    const activeThumb = thumbs[current];
    if (activeThumb && activeThumb.scrollIntoView) {
      activeThumb.scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest'
      });
    }

    preloadNeighbors();

    if (items[current].thumb) {
      mainImg.src = items[current].thumb;
      mainImg.dataset.fullsrc = items[current].original;
    }
  }
  function openLightbox(index) {
    renderLightbox(index);
    resetZoom();
    lightbox.classList.add('open');
    document.body.classList.add('ds-lightbox-open');
  }
  function closeLightbox() {
    resetZoom();
    lightbox.classList.remove('open');
    document.body.classList.remove('ds-lightbox-open');
  }

  mainImg.addEventListener('click', () => {
    const active = thumbs.findIndex(t => t.classList.contains('active'));
    openLightbox(active >= 0 ? active : 0);
  });

  thumbs.forEach((thumb, index) => {
    thumb.addEventListener('click', () => {
      thumbs.forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
      if (thumb.dataset.fullsrc) mainImg.src = thumb.dataset.fullsrc;
      mainImg.dataset.fullsrc = thumb.dataset.originalsrc || thumb.dataset.fullsrc;
      current = index;
    });
  });

  lightbox.querySelector('.ds-lightbox-close').addEventListener('click', closeLightbox);
  lightbox.querySelector('.ds-lightbox-prev').addEventListener('click', () => renderLightbox(current - 1));
  lightbox.querySelector('.ds-lightbox-next').addEventListener('click', () => { resetZoom(); renderLightbox(current + 1); });

  let scale=1, panX=0, panY=0, dragging=false, dragStartX=0, dragStartY=0;
  let pinchStartDist=0, pinchStartScale=1;

  function clampPan(){
    if(scale<=1){ panX=0; panY=0; return; }
    const rect=lbImg.getBoundingClientRect();
    const maxX=Math.max(0,(rect.width*(scale-1))/2);
    const maxY=Math.max(0,(rect.height*(scale-1))/2);
    panX=Math.max(-maxX, Math.min(maxX, panX));
    panY=Math.max(-maxY, Math.min(maxY, panY));
  }

  let zoomRAF=null;
  function applyZoom(){
    clampPan();
    if(zoomRAF) cancelAnimationFrame(zoomRAF);
    zoomRAF=requestAnimationFrame(()=>{
      lbImg.style.transform = `translate3d(${panX}px, ${panY}px, 0) scale(${scale})`;
      lbImg.style.cursor = scale>1 ? (dragging ? 'grabbing' : 'grab') : 'zoom-in';
    });
  }

  function resetZoom(){
    scale=1; panX=0; panY=0; dragging=false; applyZoom();
  }

  lbImg.addEventListener('wheel', e=>{
    if(!lightbox.classList.contains('open')) return;
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.2 : -0.2;
    scale = Math.max(1, Math.min(4, scale + delta));
    if(scale===1){ panX=0; panY=0; }
    applyZoom();
  }, {passive:false});

  lbImg.addEventListener('dblclick', ()=>{
    if(scale===1){ scale=2; } else { scale=1; panX=0; panY=0; }
    applyZoom();
  });

  lbImg.addEventListener('mousedown', e=>{
    if(scale<=1) return;
    dragging=true;
    dragStartX=e.clientX-panX;
    dragStartY=e.clientY-panY;
    applyZoom();
  });

  window.addEventListener('mousemove', e=>{
    if(!dragging) return;
    panX=e.clientX-dragStartX;
    panY=e.clientY-dragStartY;
    applyZoom();
  });

  window.addEventListener('mouseup', ()=>{
    dragging=false;
    applyZoom();
  });



  let startX=0,startY=0;
  lightbox.addEventListener('touchstart', e=>{
    if(!lightbox.classList.contains('open')) return;
    if(e.touches.length===2){
      const dx=e.touches[0].clientX-e.touches[1].clientX;
      const dy=e.touches[0].clientY-e.touches[1].clientY;
      pinchStartDist=Math.hypot(dx,dy);
      pinchStartScale=scale;
      return;
    }
    const t=e.touches[0]; startX=t.clientX; startY=t.clientY;
  }, {passive:true});

  lightbox.addEventListener('touchmove', e=>{
    if(!lightbox.classList.contains('open')) return;
    if(e.touches.length===2){
      e.preventDefault();
      const dx=e.touches[0].clientX-e.touches[1].clientX;
      const dy=e.touches[0].clientY-e.touches[1].clientY;
      const dist=Math.hypot(dx,dy);
      scale=Math.max(1, Math.min(4, pinchStartScale*(dist/pinchStartDist)));
      applyZoom();
      return;
    }
    if(scale>1 && e.touches.length===1){
      const t=e.touches[0];
      panX=t.clientX-startX;
      panY=t.clientY-startY;
      applyZoom();
    }
  }, {passive:false});

  lightbox.addEventListener('touchend', e=>{
    if(!lightbox.classList.contains('open')) return;
    if(scale>1){ return; }
    const t=e.changedTouches[0];
    const dx=t.clientX-startX, dy=t.clientY-startY;
    if(Math.abs(dx)>50 && Math.abs(dx)>Math.abs(dy)){
      if(dx<0) renderLightbox(current+1); else renderLightbox(current-1);
    } else if(Math.abs(dy)>80){
      closeLightbox();
    }
  }, {passive:true});
  lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', e => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') renderLightbox(current + 1);
    if (e.key === 'ArrowRight') renderLightbox(current - 1);
  });
})();

/* ---- cart page: quantity stepper (mirrors WooCommerce's own qty input
   so the native cart-update / AJAX-quantity behavior still applies —
   this just keeps the +/- buttons in sync with the real input) ---- */
function stepQty(btn, dir) {
  const wrap = btn.closest('.qty-stepper');
  const input = wrap.querySelector('.qty-input, input[type="number"]');
  if (!input) return;
  const min = parseInt(input.min, 10) || 1;
  let val = parseInt(input.value, 10) || min;
  val = Math.max(min, val + dir);
  input.value = val;
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

/* ---- gold offers: countdown timer, reads the end time from data-end
   (a millisecond timestamp printed server-side in front-page.php) ---- */
(function () {
  const timer = document.getElementById('goldTimer');
  if (!timer) return;
  const end = parseInt(timer.dataset.end, 10);
  const spans = timer.querySelectorAll('span');
  function render() {
    const diff = Math.max(0, end - Date.now());
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    const pad = n => String(n).padStart(2, '0');
    if (spans.length >= 3) {
      spans[0].textContent = pad(h);
      spans[1].textContent = pad(m);
      spans[2].textContent = pad(s);
    }
    if (diff > 0) requestAnimationFrame(() => setTimeout(render, 1000));
  }
  render();
})();

/* ---- header search: live AJAX product suggestions — applies to
   every search box on the page (desktop row + mobile row) ---- */
document.querySelectorAll('.search-box').forEach(searchBox => {
  const input = searchBox.querySelector('.ds-search-input');
  const box = searchBox.querySelector('.ds-search-suggest');
  if (!input || !box || typeof dentalshopData === 'undefined') return;
  let debounceTimer;

  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const term = input.value.trim();
    if (term.length < 2) { box.classList.remove('open'); return; }
    debounceTimer = setTimeout(() => {
      const url = dentalshopData.ajaxUrl + '?action=dentalshop_search&nonce=' + dentalshopData.nonce + '&term=' + encodeURIComponent(term);
      fetch(url).then(r => r.json()).then(data => {
        if (!data || !data.length) { box.innerHTML = '<p class="no-results">نتیجه‌ای یافت نشد.</p>'; box.classList.add('open'); return; }
        box.innerHTML = data.map(p =>
          `<a href="${p.url}" class="search-result-row"><img src="${p.image}" alt=""><span>${p.name}</span><b>${p.price}</b></a>`
        ).join('');
        box.classList.add('open');
      });
    }, 300);
  });

  document.addEventListener('click', (e) => {
    if (!box.contains(e.target) && e.target !== input) box.classList.remove('open');
  });
});

/* ---- single product: gallery arrows cycle through thumbnails ---- */
function galleryGo(dir) {
  const thumbs = Array.from(document.querySelectorAll('.gallery-thumbs .thumb'));
  if (!thumbs.length) return;
  const activeIdx = thumbs.findIndex(t => t.classList.contains('active'));
  const nextIdx = (activeIdx + dir + thumbs.length) % thumbs.length;
  thumbs[nextIdx].click();
}

/* Variation UI intentionally uses native WooCommerce dropdowns only. */

/* ---- footer contact widget: toggle the popup (guarded — this markup
   only exists when at least one contact item is configured) ---- */
(function () {
  const toggle = document.getElementById('contactToggle');
  const popup = document.getElementById('contactPopup');
  if (!toggle || !popup) return;
  toggle.addEventListener('click', () => popup.classList.toggle('open'));
  document.addEventListener('click', (e) => {
    if (!popup.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
      popup.classList.remove('open');
    }
  });
})();

/* ---- compact green add-to-cart toast: works for both WooCommerce AJAX
   additions and normal redirects (?added-to-cart=ID). ---- */
(function () {
  const toast = document.getElementById('dsCartToast');
  if (!toast) return;
  let timer;
  function showToast() {
    clearTimeout(timer);
    toast.classList.add('show');
    timer = setTimeout(() => toast.classList.remove('show'), 3200);
  }
  if (window.jQuery) {
    window.jQuery(document.body).on('added_to_cart', showToast);
  }
  const params = new URLSearchParams(window.location.search);
  if (params.has('added-to-cart')) {
    showToast();
    const url = new URL(window.location.href);
    url.searchParams.delete('added-to-cart');
    url.searchParams.delete('quantity');
    window.history.replaceState({}, '', url);
  }
})();

/* ---- product quantity: inject +/- buttons around WooCommerce's native
   quantity input (WC doesn't render these by default) ---- */
document.querySelectorAll('.product-actions .quantity').forEach(wrap => {
  const input = wrap.querySelector('input.qty');
  if (!input || wrap.querySelector('.qty-btn')) return;

  const minus = document.createElement('button');
  minus.type = 'button';
  minus.className = 'qty-btn qty-minus';
  minus.textContent = '−';

  const plus = document.createElement('button');
  plus.type = 'button';
  plus.className = 'qty-btn qty-plus';
  plus.textContent = '+';

  wrap.insertBefore(plus, input);
  wrap.appendChild(minus);

  function step(dir) {
    const min = parseFloat(input.min) || 1;
    const max = input.max ? parseFloat(input.max) : Infinity;
    let val = parseFloat(input.value) || min;
    val = Math.min(max, Math.max(min, val + dir));
    input.value = val;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }
  plus.addEventListener('click', () => step(1));
  minus.addEventListener('click', () => step(-1));
});

/* ---- shared "show more / show less" toggle, used by the footer blurb,
   archive category description, and any other expandable text block ---- */
function toggleMoreText(btn, targetId) {
  const el = document.getElementById(targetId);
  if (!el) return;
  const expanded = el.classList.toggle('expanded');
  btn.textContent = expanded ? 'نمایش کمتر' : 'نمایش بیشتر';
}

/* ---- product gallery: image pans to follow the cursor while zoomed ---- */
document.querySelectorAll('.product-gallery .gallery-main').forEach(frame => {
  const img = frame.querySelector('img');
  if (!img) return;
  frame.addEventListener('mousemove', (e) => {
    const rect = frame.getBoundingClientRect();
    const xPct = ((e.clientX - rect.left) / rect.width) * 100;
    const yPct = ((e.clientY - rect.top) / rect.height) * 100;
    img.style.transformOrigin = `${xPct}% ${yPct}%`;
  });
  frame.addEventListener('mouseleave', () => {
    img.style.transformOrigin = 'center center';
  });
});


// Ajtebkala mobile bottom dock sticky cart
document.addEventListener('DOMContentLoaded',function(){
  const dock=document.getElementById('at-mobile-dock');
  if(!dock) return;
  const buy=document.querySelector('.product-actions, form.cart');
  if(!buy){
    dock.classList.add('is-visible');
    return;
  }
  const btn=dock.querySelector('.at-mobile-dock__btn');
  btn?.addEventListener('click',function(){
    const target=document.querySelector('form.cart button.single_add_to_cart_button, form.cart .single_add_to_cart_button');
    if(target) target.click();
  });
  let unlocked=false;
  function check(){
    const doc=document.documentElement;
    const progress=(window.scrollY||window.pageYOffset)/(Math.max(1,doc.scrollHeight-window.innerHeight));
    if(!unlocked && progress>=0.2){
      unlocked=true;
      dock.classList.add('is-visible');
      document.querySelector('.at-contact-floating')?.classList.add('is-lifted');
    }else if(unlocked && progress<0.2){
      unlocked=false;
      dock.classList.remove('is-visible');
      document.querySelector('.at-contact-floating')?.classList.remove('is-lifted');
    }
  }
  check();
  window.addEventListener('scroll',check,{passive:true});
});

/* ---- site-wide information popup: show at most twice per browser ---- */
(function () {
  const popup = document.getElementById('dsSitePopup');
  const overlay = document.getElementById('dsSitePopupOverlay');
  const close = document.getElementById('dsSitePopupClose');
  if (!popup || !overlay) return;

  const revision = popup.dataset.revision || '1';
  const key = 'ajtebkala_site_popup_' + revision;
  let count = 0;
  try { count = parseInt(localStorage.getItem(key) || '0', 10) || 0; } catch (e) {}
  if (count >= 2) return;

  function hide() {
    popup.classList.remove('open');
    overlay.classList.remove('open');
    document.body.classList.remove('site-popup-open');
  }
  function show() {
    popup.classList.add('open');
    overlay.classList.add('open');
    document.body.classList.add('site-popup-open');
    try { localStorage.setItem(key, String(count + 1)); } catch (e) {}
  }

  setTimeout(show, 900);
  close?.addEventListener('click', hide);
  overlay.addEventListener('click', hide);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') hide(); });
})();
