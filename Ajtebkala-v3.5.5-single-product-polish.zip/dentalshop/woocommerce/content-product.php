<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $product;
if ( ! $product || ! $product->is_visible() ) return;

get_template_part( 'template-parts/product-tile', null, array( 'product' => $product ) );
