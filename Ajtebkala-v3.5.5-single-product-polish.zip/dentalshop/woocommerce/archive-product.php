<?php
/**
 * Shop / product category archive — full override so the category
 * title + description + sort toolbar + product grid + pagination can
 * all sit inside one shared "کادر X" frame, with the breadcrumb outside
 * it (per the agreed layout).
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header( 'shop' );

$ds = dentalshop_get_settings();
$is_gold_archive = ! empty( $ds['gold_product_tag'] ) && is_tax( 'product_tag', $ds['gold_product_tag'] );
?>
<div class="wrap woocommerce-page-wrap">

	<?php woocommerce_breadcrumb(); ?>

	<div class="frame-x archive-frame <?php echo $is_gold_archive ? 'archive-frame-gold' : ''; ?>">

		<?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
			<h1 class="page-title"><?php woocommerce_page_title(); ?></h1>
		<?php endif; ?>

		<?php
		/**
		 * dentalshop_archive_description() (inc/woocommerce.php) already
		 * only prints anything when the term actually has a description —
		 * still hooked to 'woocommerce_archive_description' so it keeps
		 * working exactly the same here.
		 */
		do_action( 'woocommerce_archive_description' );
		?>

		<?php if ( woocommerce_product_loop() ) : ?>

			<?php do_action( 'woocommerce_before_shop_loop' ); ?>

			<?php woocommerce_product_loop_start(); ?>

			<?php if ( wc_get_loop_prop( 'total' ) ) : while ( have_posts() ) : the_post();
				do_action( 'woocommerce_shop_loop' );
				wc_get_template_part( 'content', 'product' );
			endwhile; endif; ?>

			<?php woocommerce_product_loop_end(); ?>

			<?php do_action( 'woocommerce_after_shop_loop' ); ?>

		<?php else : ?>

			<?php do_action( 'woocommerce_no_products_found' ); ?>

		<?php endif; ?>

	</div><!-- /.archive-frame -->

</div>
<?php
get_footer( 'shop' );
