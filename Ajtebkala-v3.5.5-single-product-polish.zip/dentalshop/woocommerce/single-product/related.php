<?php
/**
 * Related products — same slider component as the homepage sliders,
 * instead of WooCommerce's default `<ul class="products">` grid.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! $related_products ) return;
?>
<section class="reveal frame-x" style="margin-top:40px;">
	<div class="section-head">
		<h2><?php esc_html_e( 'محصولات مرتبط', 'dentalshop' ); ?></h2>
	</div>
	<div class="slider-wrap">
		<div class="slider-arrow right" onclick="slide(this,-1)">‹</div>
		<div class="slider-arrow left" onclick="slide(this,1)">›</div>
		<div class="p-slider">
			<?php foreach ( $related_products as $related_product ) :
				$post_object = get_post( $related_product->get_id() );
				setup_postdata( $GLOBALS['post'] =& $post_object );
				get_template_part( 'template-parts/product-tile', null, array( 'product' => $related_product ) );
			endforeach;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
