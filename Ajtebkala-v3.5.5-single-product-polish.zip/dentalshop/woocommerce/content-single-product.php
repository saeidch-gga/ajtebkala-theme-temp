<?php
/**
 * Single product content — overrides WooCommerce's default template
 * (gallery + one summary column) with our 3-column layout: gallery /
 * short description / info+buy. We call the individual WooCommerce
 * hooks/functions directly instead of relying on the default
 * `woocommerce_single_product_summary` action group, since that action
 * bundles title+price+short-description+add-to-cart into one block and
 * we need short-description pulled into its own column.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

global $product;
if ( ! is_singular( 'product' ) ) return;
?>

<?php do_action( 'woocommerce_before_single_product' ); ?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>

	<section class="product-main">

		<!-- col 1: gallery -->
		<div class="product-gallery">
			<?php dentalshop_render_product_gallery( $product ); ?>
		</div>

		<!-- mobile-only title: a real grid child (hidden on desktop via CSS)
		     so on mobile — where the grid collapses to one column — it lands
		     in DOM order between the gallery and the short description. -->
		<h1 class="product-title mobile-only-title"><?php the_title(); ?></h1>

		<!-- col 2: short description -->
		<div class="product-short-desc">
			<div class="product-meta-row">
				<?php echo wc_get_product_category_list( $product->get_id(), ', ', '<span class="product-cat-list">', '</span>' ); ?>
				<?php if ( wc_review_ratings_enabled() && $product->get_rating_count() > 0 ) : ?>
					<span class="product-rating-inline"><?php woocommerce_template_single_rating(); ?></span>
				<?php endif; ?>
			</div>
			<?php echo apply_filters( 'woocommerce_short_description', $product->get_short_description() ); ?>
		</div>

		<!-- col 3: info + buy -->
		<div class="product-info">
			<h1 class="product-title desktop-title"><?php the_title(); ?></h1>

			<div class="product-price"><?php echo $product->get_price_html(); ?></div>

			<div class="product-actions">
				<?php woocommerce_template_single_add_to_cart(); ?>
			</div>
		</div>

	</section>

	<!-- trust row: full-width 4-column strip below gallery/short-desc/info -->
	<?php dentalshop_render_trust_mini_row(); ?>

	<!-- tabs: description + reviews -->
	<section class="product-tabs">
		<div class="tabs-head">
			<button class="tab-btn active" data-tab="desc"><?php esc_html_e( 'توضیحات محصول', 'dentalshop' ); ?></button>
			<?php if ( wc_review_ratings_enabled() || comments_open() ) : ?>
				<button class="tab-btn" data-tab="reviews"><?php esc_html_e( 'نظرات کاربران', 'dentalshop' ); ?></button>
			<?php endif; ?>
		</div>
		<div class="tab-panel active" id="tab-desc">
			<?php the_content(); ?>
		</div>
		<?php if ( wc_review_ratings_enabled() || comments_open() ) : ?>
		<div class="tab-panel" id="tab-reviews">
			<div class="comments-frame">
				<?php comments_template(); ?>
			</div>
		</div>
		<?php endif; ?>
	</section>

	<!-- related products (same slider component as everywhere else) -->
	<?php woocommerce_output_related_products(); ?>

</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
