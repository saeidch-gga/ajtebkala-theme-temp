<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
</div><!-- /.archive-grid -->
