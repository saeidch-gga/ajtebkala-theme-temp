<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $wp_query;

if ( $wp_query->max_num_pages <= 1 ) return;

$current = max( 1, get_query_var( 'paged' ) );
$links = paginate_links( array(
	'base'      => esc_url_raw( str_replace( 999999999, '%#%', remove_query_arg( 'add-to-cart', get_pagenum_link( 999999999, false ) ) ) ),
	'format'    => '',
	'current'   => $current,
	'total'     => $wp_query->max_num_pages,
	'prev_text' => '›',
	'next_text' => '‹',
	'type'      => 'array',
) );

if ( ! $links ) return;
?>
<nav class="pagination woocommerce-pagination">
	<?php foreach ( $links as $link ) :
		$class = 'page-num';
		if ( false !== strpos( $link, 'prev' ) || false !== strpos( $link, 'next' ) ) $class = 'page-arrow';
		if ( false !== strpos( $link, 'dots' ) ) $class = 'page-dots';
		$link = str_replace( 'page-numbers', $class, $link );
		echo wp_kses_post( $link );
	endforeach; ?>
</nav>
