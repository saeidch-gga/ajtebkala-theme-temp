<?php
/**
 * Account details tab.
 * The phone field is rendered read-only with a "verified" badge — this
 * is cosmetic only. If Digits is active it manages the real phone
 * number/verification state itself; this field just mirrors it.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$user_id = get_current_user_id();
?>
<h3><?php esc_html_e( 'جزئیات حساب', 'dentalshop' ); ?></h3>

<form class="woocommerce-EditAccountForm edit-account" action="" method="post">
	<?php do_action( 'woocommerce_before_edit_account_form' ); ?>

	<div class="form-grid">
		<div class="form-field field-half">
			<label for="account_first_name"><?php esc_html_e( 'نام', 'dentalshop' ); ?></label>
			<input type="text" name="account_first_name" id="account_first_name" value="<?php echo esc_attr( get_user_meta( $user_id, 'first_name', true ) ); ?>">
		</div>
		<div class="form-field field-half">
			<label for="account_last_name"><?php esc_html_e( 'نام خانوادگی', 'dentalshop' ); ?></label>
			<input type="text" name="account_last_name" id="account_last_name" value="<?php echo esc_attr( get_user_meta( $user_id, 'last_name', true ) ); ?>">
		</div>
		<div class="form-field field-half">
			<label>
				<?php esc_html_e( 'شماره موبایل', 'dentalshop' ); ?>
				<span class="verified-badge"><?php esc_html_e( 'تأیید شده', 'dentalshop' ); ?></span>
			</label>
			<input type="tel" value="<?php echo esc_attr( get_user_meta( $user_id, 'billing_phone', true ) ); ?>" dir="ltr" disabled>
		</div>
		<div class="form-field field-half">
			<label for="account_email"><?php esc_html_e( 'ایمیل (اختیاری)', 'dentalshop' ); ?></label>
			<input type="email" name="account_email" id="account_email" value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>" dir="ltr">
		</div>
	</div>

	<?php do_action( 'woocommerce_edit_account_form' ); ?>

	<p>
		<?php wp_nonce_field( 'save_account_details', 'save-account-details-nonce' ); ?>
		<button type="submit" class="btn" name="save_account_details" value="<?php esc_attr_e( 'ذخیره تغییرات', 'dentalshop' ); ?>"><?php esc_html_e( 'ذخیره تغییرات', 'dentalshop' ); ?></button>
		<input type="hidden" name="action" value="save_account_details">
	</p>

	<?php do_action( 'woocommerce_after_edit_account_form' ); ?>
</form>
