<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$current_user = wp_get_current_user();
$customer_orders = wc_get_orders( array( 'customer' => get_current_user_id(), 'limit' => -1 ) );
$processing_count = count( array_filter( $customer_orders, function ( $o ) { return $o->has_status( array( 'processing', 'on-hold' ) ); } ) );
$address_count = ( get_user_meta( get_current_user_id(), 'billing_address_1', true ) ? 1 : 0 ) + ( get_user_meta( get_current_user_id(), 'shipping_address_1', true ) ? 1 : 0 );
$latest_order = $customer_orders ? $customer_orders[0] : null;
?>
<h3><?php printf( esc_html__( 'سلام، %s', 'dentalshop' ), esc_html( $current_user->display_name ) ); ?></h3>
<p class="panel-sub"><?php esc_html_e( 'از داشبورد حساب کاربری‌تان می‌توانید سفارش‌های اخیر، آدرس‌ها و اطلاعات حساب را مدیریت کنید.', 'dentalshop' ); ?></p>

<div class="account-stats">
	<div class="stat-card"><span class="stat-num"><?php echo esc_html( count( $customer_orders ) ); ?></span><span class="stat-label"><?php esc_html_e( 'سفارش ثبت‌شده', 'dentalshop' ); ?></span></div>
	<div class="stat-card"><span class="stat-num"><?php echo esc_html( $processing_count ); ?></span><span class="stat-label"><?php esc_html_e( 'در حال پردازش', 'dentalshop' ); ?></span></div>
	<div class="stat-card"><span class="stat-num"><?php echo esc_html( $address_count ); ?></span><span class="stat-label"><?php esc_html_e( 'آدرس ذخیره‌شده', 'dentalshop' ); ?></span></div>
</div>

<?php if ( $latest_order ) : ?>
	<h4 class="panel-subhead"><?php esc_html_e( 'آخرین سفارش', 'dentalshop' ); ?></h4>
	<div class="order-row">
		<span class="order-num">#<?php echo esc_html( $latest_order->get_order_number() ); ?></span>
		<span class="order-date"><?php echo esc_html( wc_format_datetime( $latest_order->get_date_created() ) ); ?></span>
		<span class="order-status status-<?php echo esc_attr( $latest_order->get_status() ); ?>"><?php echo esc_html( wc_get_order_status_name( $latest_order->get_status() ) ); ?></span>
		<span class="order-total"><?php echo wp_kses_post( $latest_order->get_formatted_order_total() ); ?></span>
		<a href="<?php echo esc_url( $latest_order->get_view_order_url() ); ?>" class="order-view"><?php esc_html_e( 'مشاهده ←', 'dentalshop' ); ?></a>
	</div>
<?php endif; ?>
