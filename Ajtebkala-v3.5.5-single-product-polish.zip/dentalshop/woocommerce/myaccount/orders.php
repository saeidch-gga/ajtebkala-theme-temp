<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/** @var WC_Order[] $customer_orders (provided by WooCommerce core before including this template) */
?>
<h3><?php esc_html_e( 'سفارش‌های من', 'dentalshop' ); ?></h3>

<?php if ( ! $customer_orders->has_orders() ) : ?>
	<p><?php esc_html_e( 'هنوز سفارشی ثبت نکرده‌اید.', 'dentalshop' ); ?></p>
	<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="btn"><?php esc_html_e( 'مشاهده فروشگاه', 'dentalshop' ); ?></a>
<?php else : ?>
	<div class="order-row order-row-head">
		<span><?php esc_html_e( 'شماره', 'dentalshop' ); ?></span>
		<span><?php esc_html_e( 'تاریخ', 'dentalshop' ); ?></span>
		<span><?php esc_html_e( 'وضعیت', 'dentalshop' ); ?></span>
		<span><?php esc_html_e( 'مبلغ', 'dentalshop' ); ?></span>
		<span></span>
	</div>
	<?php foreach ( $customer_orders->orders as $customer_order ) :
		$order = wc_get_order( $customer_order );
		?>
		<div class="order-row">
			<span class="order-num">#<?php echo esc_html( $order->get_order_number() ); ?></span>
			<span class="order-date"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></span>
			<span class="order-status status-<?php echo esc_attr( $order->get_status() ); ?>"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
			<span class="order-total"><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></span>
			<a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="order-view"><?php esc_html_e( 'مشاهده ←', 'dentalshop' ); ?></a>
		</div>
	<?php endforeach; ?>

	<?php if ( 1 < $customer_orders->max_num_pages ) : ?>
		<nav class="pagination">
			<?php if ( 1 !== $customer_orders->current_page ) : ?>
				<a class="page-arrow" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $customer_orders->current_page - 1 ) ); ?>">‹</a>
			<?php endif; ?>
			<?php if ( intval( $customer_orders->max_num_pages ) !== $customer_orders->current_page ) : ?>
				<a class="page-arrow" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $customer_orders->current_page + 1 ) ); ?>">›</a>
			<?php endif; ?>
		</nav>
	<?php endif; ?>
<?php endif; ?>
