<?php
/**
 * My Account page wrapper.
 *
 * Logged OUT: no sidebar — just whatever `woocommerce_account_content`
 * renders (WooCommerce's default myaccount/form-login.php, UNLESS the
 * Digits plugin is active, in which case Digits hooks into that same
 * action and renders its own phone+OTP form instead — this theme
 * intentionally never overrides form-login.php so Digits owns it).
 *
 * Logged IN: our sidebar (dashboard / orders / addresses / account
 * details / logout) + content card, matching the rest of the site.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

do_action( 'woocommerce_before_account_navigation' );

if ( ! is_user_logged_in() ) {
	?>
	<div class="auth-view">
		<div class="auth-card">
			<?php do_action( 'woocommerce_account_content' ); ?>
		</div>
	</div>
	<?php
	return;
}
?>

<div class="account-layout">
	<aside class="account-sidebar">
		<div class="account-user">
			<div class="account-avatar"><?php echo esc_html( mb_substr( wp_get_current_user()->display_name, 0, 1 ) ); ?></div>
			<div class="account-user-info">
				<b><?php echo esc_html( wp_get_current_user()->display_name ); ?></b>
				<span dir="ltr"><?php echo esc_html( get_user_meta( get_current_user_id(), 'billing_phone', true ) ); ?></span>
			</div>
		</div>
		<?php do_action( 'woocommerce_account_navigation' ); ?>
	</aside>

	<div class="account-content">
		<?php do_action( 'woocommerce_account_content' ); ?>
	</div>
</div>
