<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$customer_id = get_current_user_id();
$address_types = apply_filters( 'woocommerce_my_account_get_addresses', array(
	'billing'  => __( 'آدرس صورت‌حساب', 'dentalshop' ),
	'shipping' => __( 'آدرس ارسال', 'dentalshop' ),
), $customer_id );

// If we're on the actual edit-address/{type}/ endpoint, fall back to WooCommerce's real edit form.
global $wp;
if ( ! empty( $wp->query_vars['edit-address'] ) ) {
	$load_address = sanitize_title( $wp->query_vars['edit-address'] );
	?>
	<h3><?php echo esc_html( $address_types[ $load_address ] ?? __( 'ویرایش آدرس', 'dentalshop' ) ); ?></h3>
	<form method="post" class="woocommerce-address-fields">
		<div class="form-grid">
			<?php
			$fields = WC()->countries->get_address_fields( WC()->customer->get_billing_country(), $load_address . '_' );
			foreach ( $fields as $key => $field ) {
				echo '<div class="form-field ' . ( ! empty( $field['class'] ) && in_array( 'form-row-wide', (array) $field['class'], true ) ? 'field-full' : 'field-half' ) . '">';
				$value = is_callable( array( WC()->customer, "get_$key" ) ) ? WC()->customer->{"get_$key"}() : '';
				woocommerce_form_field( $key, $field, $value );
				echo '</div>';
			}
			?>
		</div>
		<?php wp_nonce_field( 'woocommerce-edit_address', 'woocommerce-edit-address-nonce' ); ?>
		<button type="submit" class="btn" name="save_address"><?php esc_html_e( 'ذخیره آدرس', 'dentalshop' ); ?></button>
	</form>
	<?php
	return;
}
?>

<h3><?php esc_html_e( 'آدرس‌های من', 'dentalshop' ); ?></h3>
<div class="address-grid">
	<?php foreach ( $address_types as $type => $title ) :
		$address = wc_get_account_formatted_address( $type );
		?>
		<div class="address-card">
			<div class="address-card-head">
				<b><?php echo esc_html( $title ); ?></b>
				<a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address', $type ) ); ?>"><?php esc_html_e( 'ویرایش', 'dentalshop' ); ?></a>
			</div>
			<?php if ( $address ) : ?>
				<p><?php echo wp_kses_post( $address ); ?></p>
			<?php else : ?>
				<p><?php esc_html_e( 'هنوز آدرسی ثبت نشده است.', 'dentalshop' ); ?></p>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>
