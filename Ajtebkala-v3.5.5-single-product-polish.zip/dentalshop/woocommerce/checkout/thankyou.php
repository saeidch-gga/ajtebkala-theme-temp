<?php
/**
 * Ajtebkala custom WooCommerce thank-you page.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$order = ( isset( $order ) && $order instanceof WC_Order ) ? $order : false;
$order_id = $order ? $order->get_id() : absint( $order_id ?? 0 );

// WooCommerce normally passes order_id, but keep the page robust across
// checkout/thank-you variations, HPOS, gateways and order-key URLs.
if ( ! $order_id && function_exists( 'get_query_var' ) ) {
	$order_id = absint( get_query_var( 'order-received' ) );
}
if ( ! $order_id && isset( $_GET['key'] ) && function_exists( 'wc_get_order_id_by_order_key' ) ) {
	$order_key = wc_clean( wp_unslash( $_GET['key'] ) );
	$order_id  = absint( wc_get_order_id_by_order_key( $order_key ) );
}
if ( ! $order && $order_id ) {
	$order = wc_get_order( $order_id );
}

get_header( 'shop' );
?>
<div class="wrap woocommerce-page-wrap">
	<div class="ds-thankyou-wrap">
		<?php if ( $order ) : ?>
			<?php do_action( 'woocommerce_before_thankyou', $order_id ); ?>
			<div class="ds-thankyou-card">
				<div class="ds-thankyou-head">
					<div class="ds-thankyou-check" aria-hidden="true">✓</div>
					<h1><?php esc_html_e( 'سفارش شما با موفقیت ثبت شد', 'dentalshop' ); ?></h1>
					<p><?php esc_html_e( 'از خرید شما سپاسگزاریم. اطلاعات سفارش شما در زیر نمایش داده شده است.', 'dentalshop' ); ?></p>
				</div>

				<div class="ds-thankyou-order">
					<div class="ds-thankyou-order-item"><span>شماره سفارش</span><strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong></div>
					<div class="ds-thankyou-order-item"><span>تاریخ ثبت</span><strong><?php echo esc_html( $order->get_date_created() ? ajtebkala_jalali_datetime( $order->get_date_created()->getTimestamp() ) : '—' ); ?></strong></div>
					<div class="ds-thankyou-order-item"><span>روش پرداخت</span><strong><?php echo esc_html( $order->get_payment_method_title() ?: '—' ); ?></strong></div>
					<div class="ds-thankyou-order-item"><span>مبلغ نهایی</span><strong><?php echo wp_kses_post( wc_price( $order->get_total() ) ); ?></strong></div>
				</div>

				<div class="ds-thankyou-body">
					<h2>جزئیات سفارش</h2>
					<table class="ds-thankyou-table">
						<thead><tr><th>محصول</th><th>تعداد</th><th>مبلغ</th></tr></thead>
						<tbody>
						<?php foreach ( $order->get_items( 'line_item' ) as $item ) : ?>
							<tr>
								<td><?php echo esc_html( $item->get_name() ); ?></td>
								<td><?php echo esc_html( $item->get_quantity() ); ?></td>
								<td class="ds-thankyou-total"><?php echo wp_kses_post( wc_price( $item->get_total(), array( 'currency' => $order->get_currency() ) ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>

					<div class="ds-thankyou-addresses">
						<div class="ds-thankyou-address">
							<h3>اطلاعات خریدار</h3>
							<address>
								<strong><?php echo esc_html( trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ); ?></strong><br>
								<?php echo esc_html( $order->get_billing_phone() ); ?><br>
								<?php echo esc_html( $order->get_billing_email() ); ?>
							</address>
						</div>
						<div class="ds-thankyou-address">
							<h3>آدرس ارسال</h3>
							<address>
								<?php echo wp_kses_post( $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address() ); ?><br>
								<strong>کدپستی:</strong> <?php echo esc_html( $order->get_shipping_postcode() ?: $order->get_billing_postcode() ); ?>
							</address>
						</div>
					</div>

					<div class="ds-thankyou-actions">
						<a class="btn" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>">مشاهده حساب کاربری</a>
						<a class="btn btn-outline" href="<?php echo esc_url( home_url( '/' ) ); ?>">بازگشت به فروشگاه</a>
					</div>
				</div>
			</div>
			<?php do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order_id ); ?>
			<?php do_action( 'woocommerce_thankyou', $order_id ); ?>
		<?php else : ?>
			<div class="ds-thankyou-card"><div class="ds-thankyou-body"><h1><?php esc_html_e( 'سفارش شما ثبت شد.', 'dentalshop' ); ?></h1><p><?php esc_html_e( 'جزئیات سفارش در دسترس نیست.', 'dentalshop' ); ?></p></div></div>
		<?php endif; ?>
	</div>
</div>
<?php get_footer( 'shop' ); ?>
