<?php
/**
 * Checkout page. Same core hooks/structure as WooCommerce's own
 * form-checkout.php (login prompt, coupon form suppressed per design,
 * order review, payment) — just laid out in our two-column design.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! defined( 'WOOCOMMERCE_CHECKOUT' ) ) define( 'WOOCOMMERCE_CHECKOUT', true );

do_action( 'woocommerce_before_checkout_form', $checkout );

if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'برای ادامه‌ی خرید باید وارد حساب کاربری خود شوید.', 'dentalshop' ) ) );
	return;
}
?>

<h1 class="page-title"><?php esc_html_e( 'تکمیل خرید', 'dentalshop' ); ?></h1>

<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

	<?php if ( $checkout->get_checkout_fields() ) : ?>
		<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

		<div class="checkout-layout">

			<div class="checkout-form-card">
				<h3><?php esc_html_e( 'اطلاعات ارسال', 'dentalshop' ); ?></h3>

				<div class="form-grid">
					<?php foreach ( $checkout->get_checkout_fields( 'billing' ) as $key => $field ) :
						echo '<div class="form-field ' . ( ! empty( $field['class'] ) && in_array( 'form-row-wide', (array) $field['class'], true ) ? 'field-full' : 'field-half' ) . '">';
						woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
						echo '</div>';
					endforeach; ?>

					<?php if ( $checkout->get_checkout_fields( 'order' ) ) : ?>
						<?php foreach ( $checkout->get_checkout_fields( 'order' ) as $key => $field ) : ?>
							<div class="form-field field-full">
								<?php woocommerce_form_field( $key, $field, $checkout->get_value( $key ) ); ?>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>

			<div class="cart-summary-card">
				<?php wc_get_template( 'checkout/review-order.php', array( 'checkout' => $checkout ) ); ?>
			</div>
		</div>

		<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>
	<?php endif; ?>

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
