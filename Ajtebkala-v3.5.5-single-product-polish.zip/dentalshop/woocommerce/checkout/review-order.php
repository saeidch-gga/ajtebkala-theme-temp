<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$cart = WC()->cart;
?>
<h3><?php esc_html_e( 'خلاصه‌ی سفارش', 'dentalshop' ); ?></h3>

<div class="mini-cart-list">
	<?php foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) :
		$product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
		if ( ! $product || ! apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) continue;
		?>
		<div class="mini-cart-item">
			<div class="mini-cart-thumb">
				<?php echo $product->get_image( array( 44, 44 ) ); ?>
				<span class="mini-cart-qty"><?php echo esc_html( $cart_item['quantity'] ); ?></span>
			</div>
			<span class="mini-cart-name"><?php echo wp_kses_post( apply_filters( 'woocommerce_checkout_cart_item_name', $product->get_name(), $cart_item, $cart_item_key ) ); ?></span>
			<span class="mini-cart-price"><?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' ' . $cart->get_product_subtotal( $product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?></span>
		</div>
	<?php endforeach; ?>
</div>

<div class="summary-line">
	<span><?php esc_html_e( 'جمع کل کالاها', 'dentalshop' ); ?></span>
	<span><?php wc_cart_totals_subtotal_html(); ?></span>
</div>

<?php if ( $cart->needs_shipping() && $cart->show_shipping() ) : ?>
	<div class="shipping-methods">
		<span class="summary-label"><?php esc_html_e( 'روش ارسال', 'dentalshop' ); ?></span>
		<?php wc_cart_totals_shipping_html(); // Advanced Shipping's methods render here, same as the cart page ?>
	</div>
<?php endif; ?>

<?php foreach ( $cart->get_fees() as $fee ) : ?>
	<div class="summary-line"><span><?php echo esc_html( $fee->name ); ?></span><span><?php wc_cart_totals_fee_html( $fee ); ?></span></div>
<?php endforeach; ?>

<div class="summary-line summary-total">
	<span><?php esc_html_e( 'مبلغ قابل پرداخت', 'dentalshop' ); ?></span>
	<span><?php wc_cart_totals_order_total_html(); ?></span>
</div>

<div class="payment-methods">
	<span class="summary-label"><?php esc_html_e( 'روش پرداخت', 'dentalshop' ); ?></span>
	<?php
	/**
	 * Reuses WooCommerce core's own payment.php partial — this is the
	 * exact hook point every payment gateway plugin expects, so calling
	 * it directly (instead of looping WC()->payment_gateways() by hand)
	 * keeps every gateway, including custom/Iranian gateway plugins,
	 * working without modification.
	 */
	wc_get_template( 'checkout/payment.php' );
	?>
</div>
