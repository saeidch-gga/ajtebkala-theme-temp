<?php
/**
 * Cart page. Structure follows WooCommerce core's cart.php closely
 * (same hooks, same form) so quantity updates, coupon application, and
 * third-party shipping plugins keep working — only the item markup and
 * the totals wrapper are restyled.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

do_action( 'woocommerce_before_cart' ); ?>

<h1 class="page-title"><?php esc_html_e( 'سبد خرید شما', 'dentalshop' ); ?></h1>

<form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
	<?php do_action( 'woocommerce_before_cart_table' ); ?>

	<div class="cart-layout">
		<div class="cart-items-card">
			<div class="cart-row cart-row-head">
				<div class="cart-row-thumb"></div>
				<div class="cart-row-info"><?php esc_html_e( 'محصول', 'dentalshop' ); ?></div>
				<div class="cart-row-price"><?php esc_html_e( 'قیمت واحد', 'dentalshop' ); ?></div>
				<div class="qty-stepper-label"><?php esc_html_e( 'تعداد', 'dentalshop' ); ?></div>
				<div class="cart-row-subtotal"><?php esc_html_e( 'جمع جزء', 'dentalshop' ); ?></div>
				<div></div>
			</div>

			<?php
			do_action( 'woocommerce_before_cart_contents' );

			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
				$product_id  = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

				if ( ! $product || ! $product->exists() || $cart_item['quantity'] <= 0 || ! apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
					continue;
				}
				?>
				<div class="cart-row" data-key="<?php echo esc_attr( $cart_item_key ); ?>">
					<div class="cart-row-thumb"><?php echo $product->get_image( 'thumbnail' ); ?></div>
					<div class="cart-row-info">
						<div class="cart-row-name"><?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $product->get_name(), $cart_item, $cart_item_key ) ); ?></div>
						<div class="cart-row-meta"><?php echo wc_get_formatted_cart_item_data( $cart_item ); ?></div>
						<div class="cart-row-price-mobile"><?php echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $product ), $cart_item, $cart_item_key ); ?></div>
					</div>
					<div class="cart-row-price"><?php echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $product ), $cart_item, $cart_item_key ); ?></div>

					<div class="qty-stepper">
						<button type="button" class="qty-btn" onclick="stepQty(this,-1)">−</button>
						<?php
						echo woocommerce_quantity_input(
							array(
								'input_name'   => "cart[{$cart_item_key}][qty]",
								'input_value'  => $cart_item['quantity'],
								'max_value'    => $product->get_max_purchase_quantity(),
								'min_value'    => '0',
								'product_name' => $product->get_name(),
								'classes'      => array( 'qty-input' ),
							),
							$product,
							false
						);
						?>
						<button type="button" class="qty-btn" onclick="stepQty(this,1)">+</button>
					</div>

					<div class="cart-row-subtotal"><?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?></div>

					<?php
					$remove_url = wc_get_cart_remove_url( $cart_item_key );
					echo '<a href="' . esc_url( $remove_url ) . '" class="cart-row-remove" title="' . esc_attr__( 'حذف از سبد خرید', 'dentalshop' ) . '" data-product_id="' . esc_attr( $product_id ) . '">✕</a>';
					?>
				</div>
				<?php
			}

			do_action( 'woocommerce_cart_contents' );
			?>

			<div class="cart-coupon-row">
				<?php if ( wc_coupons_enabled() ) : ?>
					<input type="text" name="coupon_code" class="coupon-input" placeholder="<?php esc_attr_e( 'کد تخفیف را وارد کنید', 'dentalshop' ); ?>" value="">
					<button type="submit" class="btn btn-outline" name="apply_coupon"><?php esc_html_e( 'اعمال کد تخفیف', 'dentalshop' ); ?></button>
				<?php endif; ?>
				<a href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>" class="continue-shopping">← <?php esc_html_e( 'ادامه‌ی خرید', 'dentalshop' ); ?></a>
				<?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
				<button type="submit" class="btn" name="update_cart" style="display:none;"><?php esc_html_e( 'به‌روزرسانی سبد خرید', 'dentalshop' ); ?></button>
			</div>

			<?php do_action( 'woocommerce_after_cart_contents' ); ?>
		</div>

		<div class="cart-summary-card">
			<?php do_action( 'woocommerce_cart_collaterals' ); ?>
		</div>
	</div>

	<?php do_action( 'woocommerce_after_cart_table' ); ?>
</form>

<?php do_action( 'woocommerce_after_cart' ); ?>
