<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="btn btn-checkout wc-proceed-to-checkout">
	<?php esc_html_e( 'ادامه‌ی فرآیند خرید ←', 'dentalshop' ); ?>
</a>
