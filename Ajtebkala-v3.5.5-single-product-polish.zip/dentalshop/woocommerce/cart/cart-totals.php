<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$cart = WC()->cart;
do_action( 'woocommerce_before_cart_totals' );
?>
<h3><?php esc_html_e( 'خلاصه‌ی سفارش', 'dentalshop' ); ?></h3>

<div class="summary-line">
	<span><?php esc_html_e( 'جمع کل کالاها', 'dentalshop' ); ?></span>
	<span><?php wc_cart_totals_subtotal_html(); ?></span>
</div>

<?php foreach ( $cart->get_coupons() as $code => $coupon ) : ?>
	<div class="summary-line">
		<span><?php wc_cart_totals_coupon_label( $coupon ); ?></span>
		<span><?php wc_cart_totals_coupon_html( $coupon ); ?></span>
	</div>
<?php endforeach; ?>

<?php if ( $cart->needs_shipping() && $cart->show_shipping() ) : ?>
	<div class="shipping-methods">
		<span class="summary-label"><?php esc_html_e( 'روش ارسال', 'dentalshop' ); ?></span>
		<?php
		/**
		 * wc_cart_totals_shipping_html() is WooCommerce's own dynamic
		 * shipping-method renderer — this is exactly where a plugin like
		 * Advanced Shipping for WooCommerce injects its custom methods, so
		 * calling it directly (rather than hand-building the method list)
		 * keeps that plugin (and any other shipping plugin) working as-is.
		 * CSS below reskins its default `ul.woocommerce-shipping-methods`
		 * markup into our `.shipping-option` card look.
		 */
		wc_cart_totals_shipping_html();
		?>
	</div>
<?php endif; ?>

<?php foreach ( $cart->get_fees() as $fee ) : ?>
	<div class="summary-line">
		<span><?php echo esc_html( $fee->name ); ?></span>
		<span><?php wc_cart_totals_fee_html( $fee ); ?></span>
	</div>
<?php endforeach; ?>

<?php if ( wc_tax_enabled() && ! $cart->display_prices_including_tax() ) :
	if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) :
		foreach ( $cart->get_tax_totals() as $code => $tax ) : ?>
			<div class="summary-line"><span><?php echo esc_html( $tax->label ); ?></span><span><?php echo wp_kses_post( $tax->formatted_amount ); ?></span></div>
		<?php endforeach;
	else : ?>
		<div class="summary-line"><span><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></span><span><?php wc_cart_totals_taxes_total_html(); ?></span></div>
	<?php endif;
endif; ?>

<div class="summary-line summary-total">
	<span><?php esc_html_e( 'مبلغ قابل پرداخت', 'dentalshop' ); ?></span>
	<span><?php wc_cart_totals_order_total_html(); ?></span>
</div>

<?php do_action( 'woocommerce_proceed_to_checkout' ); ?>

<?php do_action( 'woocommerce_after_cart_totals' ); ?>
