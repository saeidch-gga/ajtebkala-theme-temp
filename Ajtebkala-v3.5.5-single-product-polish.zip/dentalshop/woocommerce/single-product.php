<?php
/**
 * Single product page — full override (not just the content partial)
 * so the breadcrumb is guaranteed to render exactly where we want it,
 * instead of depending on WooCommerce's default hook order.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header( 'shop' );
?>
<div class="wrap woocommerce-page-wrap">
	<?php woocommerce_breadcrumb(); ?>

	<?php while ( have_posts() ) : the_post(); ?>
		<?php wc_get_template_part( 'content', 'single-product' ); ?>
	<?php endwhile; ?>
</div>
<?php
get_footer( 'shop' );
