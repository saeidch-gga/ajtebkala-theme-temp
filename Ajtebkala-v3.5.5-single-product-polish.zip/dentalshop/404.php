<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<div class="wrap" style="padding: 30px 0 60px;">
	<nav class="breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'dentalshop' ); ?></a><span>/</span>
		<span class="current"><?php esc_html_e( 'صفحه پیدا نشد', 'dentalshop' ); ?></span>
	</nav>

	<div class="frame-x" style="text-align:center; padding:60px 24px;">
		<h1 class="page-title" style="margin-top:0;"><?php esc_html_e( 'صفحه‌ی مورد نظر پیدا نشد', 'dentalshop' ); ?></h1>
		<p style="color:var(--stone); margin-bottom:24px;"><?php esc_html_e( 'ممکن است آدرس اشتباه باشد یا صفحه حذف شده باشد. می‌توانید در فروشگاه جستجو کنید یا به صفحه اصلی برگردید.', 'dentalshop' ); ?></p>

		<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="max-width:420px; margin:0 auto 28px; position:relative;">
			<input type="text" name="s" placeholder="<?php esc_attr_e( 'جستجوی محصول...', 'dentalshop' ); ?>"
				style="width:100%; padding:0.85rem 1rem; border:1px solid var(--line); border-radius:8px; font-family:inherit; font-size:0.9rem; background:var(--paper-dim);">
			<input type="hidden" name="post_type" value="product">
		</form>

		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn"><?php esc_html_e( 'بازگشت به صفحه اصلی', 'dentalshop' ); ?></a>
	</div>
</div>
<?php get_footer();
